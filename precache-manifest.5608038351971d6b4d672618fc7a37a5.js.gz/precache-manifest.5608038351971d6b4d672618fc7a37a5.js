self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "05198e2bcc6d7e6df36f1baadaa439a9",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "12114e3bb12a28109cc4",
    "url": "/Covid19-Peru/static/css/10.9202e915.chunk.css"
  },
  {
    "revision": "7722daa14b120a5e4034",
    "url": "/Covid19-Peru/static/css/11.9202e915.chunk.css"
  },
  {
    "revision": "abf996c2a914719eb006",
    "url": "/Covid19-Peru/static/css/4.de424728.chunk.css"
  },
  {
    "revision": "670e5680bf054487bb63",
    "url": "/Covid19-Peru/static/css/5.14cc9829.chunk.css"
  },
  {
    "revision": "6e7038dc160cec4c1937",
    "url": "/Covid19-Peru/static/css/6.34468ac6.chunk.css"
  },
  {
    "revision": "3f95e6e8684a783a495d",
    "url": "/Covid19-Peru/static/css/7.0aaac4c2.chunk.css"
  },
  {
    "revision": "df78cbc71ebb4779441e",
    "url": "/Covid19-Peru/static/css/8.49f26715.chunk.css"
  },
  {
    "revision": "1b8fe117544e7911823d",
    "url": "/Covid19-Peru/static/css/9.de8242ae.chunk.css"
  },
  {
    "revision": "5cd052d90910e3ee0dd0",
    "url": "/Covid19-Peru/static/js/index.0.0235a46e.production.chunk.min.js"
  },
  {
    "revision": "4a9510009caeb48038e0",
    "url": "/Covid19-Peru/static/js/index.1.01af252d.production.chunk.min.js"
  },
  {
    "revision": "12114e3bb12a28109cc4",
    "url": "/Covid19-Peru/static/js/index.10.1045a9cb.production.chunk.min.js"
  },
  {
    "revision": "7722daa14b120a5e4034",
    "url": "/Covid19-Peru/static/js/index.11.14088754.production.chunk.min.js"
  },
  {
    "revision": "b33d3ed28987be676b00",
    "url": "/Covid19-Peru/static/js/index.346dc950.production.min.js"
  },
  {
    "revision": "abf996c2a914719eb006",
    "url": "/Covid19-Peru/static/js/index.4.92461d64.production.chunk.min.js"
  },
  {
    "revision": "f231859d6585c4cd5f80c344783ed269",
    "url": "/Covid19-Peru/static/js/index.4.92461d64.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "670e5680bf054487bb63",
    "url": "/Covid19-Peru/static/js/index.5.189786b3.production.chunk.min.js"
  },
  {
    "revision": "6e7038dc160cec4c1937",
    "url": "/Covid19-Peru/static/js/index.6.df14cbf0.production.chunk.min.js"
  },
  {
    "revision": "3f95e6e8684a783a495d",
    "url": "/Covid19-Peru/static/js/index.7.a957968b.production.chunk.min.js"
  },
  {
    "revision": "df78cbc71ebb4779441e",
    "url": "/Covid19-Peru/static/js/index.8.b077cc7a.production.chunk.min.js"
  },
  {
    "revision": "1b8fe117544e7911823d",
    "url": "/Covid19-Peru/static/js/index.9.16773e0b.production.chunk.min.js"
  },
  {
    "revision": "b018ec5a160176884650",
    "url": "/Covid19-Peru/static/js/index.main.32f635ec.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "2b56a4a4935a33ecef18e9543901a931",
    "url": "/Covid19-Peru/static/media/conversacion.2b56a4a4.svg"
  },
  {
    "revision": "6a2667fe962749da85b25a534c52244a",
    "url": "/Covid19-Peru/static/media/coronavirus192.6a2667fe.png"
  },
  {
    "revision": "700dba7024b41484270b6d1dc85d2f7d",
    "url": "/Covid19-Peru/static/media/facebook.700dba70.svg"
  },
  {
    "revision": "231a5fc81a7a78d0308dccd5cabecc6e",
    "url": "/Covid19-Peru/static/media/herramienta.231a5fc8.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "876e2cee5a6b9e5a0a0b429f0f760be9",
    "url": "/Covid19-Peru/static/media/icomoon.876e2cee.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "c9f1200836515fd4bacd29160be78732",
    "url": "/Covid19-Peru/static/media/twitter.c9f12008.svg"
  },
  {
    "revision": "a51ab7ed010a415170cd93a2a29d96dd",
    "url": "/Covid19-Peru/static/media/youtube.a51ab7ed.svg"
  }
]);