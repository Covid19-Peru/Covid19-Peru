self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d3e3218228d837c11af40bb7854cbf48",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "7d072c055e59785a1985",
    "url": "/Covid19-Peru/static/css/10.9202e915.chunk.css"
  },
  {
    "revision": "abf996c2a914719eb006",
    "url": "/Covid19-Peru/static/css/4.de424728.chunk.css"
  },
  {
    "revision": "6ab207301effbbb1b018",
    "url": "/Covid19-Peru/static/css/5.e7f7d8e1.chunk.css"
  },
  {
    "revision": "53f8eb357aa1c024e0e2",
    "url": "/Covid19-Peru/static/css/6.03696358.chunk.css"
  },
  {
    "revision": "5f02396ea90b6c06bae7",
    "url": "/Covid19-Peru/static/css/7.f194c86d.chunk.css"
  },
  {
    "revision": "6699a20eceda70fcc5ba",
    "url": "/Covid19-Peru/static/css/8.80af2923.chunk.css"
  },
  {
    "revision": "57bd98f37143068261a3",
    "url": "/Covid19-Peru/static/css/9.9202e915.chunk.css"
  },
  {
    "revision": "391feca43b444ec80448",
    "url": "/Covid19-Peru/static/js/index.0.93717a2c.production.chunk.min.js"
  },
  {
    "revision": "4064babf74234308a194",
    "url": "/Covid19-Peru/static/js/index.1.667a6008.production.chunk.min.js"
  },
  {
    "revision": "7d072c055e59785a1985",
    "url": "/Covid19-Peru/static/js/index.10.87bdba62.production.chunk.min.js"
  },
  {
    "revision": "0926e0388766e5c88faf",
    "url": "/Covid19-Peru/static/js/index.11.7eb9fcb9.production.chunk.min.js"
  },
  {
    "revision": "3b543bcdbf7395cba736",
    "url": "/Covid19-Peru/static/js/index.12.80c450e4.production.chunk.min.js"
  },
  {
    "revision": "abf996c2a914719eb006",
    "url": "/Covid19-Peru/static/js/index.4.92461d64.production.chunk.min.js"
  },
  {
    "revision": "f231859d6585c4cd5f80c344783ed269",
    "url": "/Covid19-Peru/static/js/index.4.92461d64.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "6ab207301effbbb1b018",
    "url": "/Covid19-Peru/static/js/index.5.eb8089cb.production.chunk.min.js"
  },
  {
    "revision": "53f8eb357aa1c024e0e2",
    "url": "/Covid19-Peru/static/js/index.6.0da020be.production.chunk.min.js"
  },
  {
    "revision": "5f02396ea90b6c06bae7",
    "url": "/Covid19-Peru/static/js/index.7.6d8abd87.production.chunk.min.js"
  },
  {
    "revision": "6699a20eceda70fcc5ba",
    "url": "/Covid19-Peru/static/js/index.8.66e60d38.production.chunk.min.js"
  },
  {
    "revision": "57bd98f37143068261a3",
    "url": "/Covid19-Peru/static/js/index.9.6804281b.production.chunk.min.js"
  },
  {
    "revision": "ad734c7cd982d9ac212f",
    "url": "/Covid19-Peru/static/js/index.d84990e3.production.min.js"
  },
  {
    "revision": "44d22c6d655b6ee9a838",
    "url": "/Covid19-Peru/static/js/index.main.bfff2cc6.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "6a2667fe962749da85b25a534c52244a",
    "url": "/Covid19-Peru/static/media/coronavirus192.6a2667fe.png"
  },
  {
    "revision": "700dba7024b41484270b6d1dc85d2f7d",
    "url": "/Covid19-Peru/static/media/facebook.700dba70.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "876e2cee5a6b9e5a0a0b429f0f760be9",
    "url": "/Covid19-Peru/static/media/icomoon.876e2cee.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "c9f1200836515fd4bacd29160be78732",
    "url": "/Covid19-Peru/static/media/twitter.c9f12008.svg"
  },
  {
    "revision": "a51ab7ed010a415170cd93a2a29d96dd",
    "url": "/Covid19-Peru/static/media/youtube.a51ab7ed.svg"
  }
]);