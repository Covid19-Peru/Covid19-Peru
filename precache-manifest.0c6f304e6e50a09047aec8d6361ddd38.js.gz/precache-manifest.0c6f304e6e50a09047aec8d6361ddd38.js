self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7509a05f0555205c246e1ca218003dba",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "efc1677a23385788e173",
    "url": "/Covid19-Peru/static/css/10.3d32d9ea.chunk.css"
  },
  {
    "revision": "01c0b3466887d3c6f326",
    "url": "/Covid19-Peru/static/css/11.b3abbe3d.chunk.css"
  },
  {
    "revision": "595ccf58340663172f0e",
    "url": "/Covid19-Peru/static/css/3.3adc8b4e.chunk.css"
  },
  {
    "revision": "58c978b49c7927667a8e",
    "url": "/Covid19-Peru/static/css/4.36193cd3.chunk.css"
  },
  {
    "revision": "c870b78d2e8ed55a94b0",
    "url": "/Covid19-Peru/static/css/5.cb88b805.chunk.css"
  },
  {
    "revision": "96be2f2555ebb05969ab",
    "url": "/Covid19-Peru/static/css/6.3d32d9ea.chunk.css"
  },
  {
    "revision": "724f92b0ba22cf15912f",
    "url": "/Covid19-Peru/static/css/7.67d967f3.chunk.css"
  },
  {
    "revision": "7156f5cbea33e59a3815",
    "url": "/Covid19-Peru/static/css/9.236d1f20.chunk.css"
  },
  {
    "revision": "cf679884c4c830101703",
    "url": "/Covid19-Peru/static/css/main.df89a53d.chunk.css"
  },
  {
    "revision": "d4135ffc94bb542ce4fe",
    "url": "/Covid19-Peru/static/js/index.0.677d46cf.production.chunk.min.js"
  },
  {
    "revision": "efc1677a23385788e173",
    "url": "/Covid19-Peru/static/js/index.10.20c1cc0d.production.chunk.min.js"
  },
  {
    "revision": "01c0b3466887d3c6f326",
    "url": "/Covid19-Peru/static/js/index.11.0f678e89.production.chunk.min.js"
  },
  {
    "revision": "995eba648da1af4a9034",
    "url": "/Covid19-Peru/static/js/index.12.c3319b6a.production.chunk.min.js"
  },
  {
    "revision": "595ccf58340663172f0e",
    "url": "/Covid19-Peru/static/js/index.3.9421e41e.production.chunk.min.js"
  },
  {
    "revision": "5035c289b7f4237f99c5f07b46faf6d0",
    "url": "/Covid19-Peru/static/js/index.3.9421e41e.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "58c978b49c7927667a8e",
    "url": "/Covid19-Peru/static/js/index.4.af4917a8.production.chunk.min.js"
  },
  {
    "revision": "c870b78d2e8ed55a94b0",
    "url": "/Covid19-Peru/static/js/index.5.8f9b1d8b.production.chunk.min.js"
  },
  {
    "revision": "96be2f2555ebb05969ab",
    "url": "/Covid19-Peru/static/js/index.6.eb4e3e39.production.chunk.min.js"
  },
  {
    "revision": "724f92b0ba22cf15912f",
    "url": "/Covid19-Peru/static/js/index.7.bd6eeaa1.production.chunk.min.js"
  },
  {
    "revision": "377ab84954710f6beeba",
    "url": "/Covid19-Peru/static/js/index.8.bb3811ca.production.chunk.min.js"
  },
  {
    "revision": "7156f5cbea33e59a3815",
    "url": "/Covid19-Peru/static/js/index.9.42edda93.production.chunk.min.js"
  },
  {
    "revision": "67e79cce4e62efcc4212",
    "url": "/Covid19-Peru/static/js/index.b88b0646.production.min.js"
  },
  {
    "revision": "cf679884c4c830101703",
    "url": "/Covid19-Peru/static/js/index.main.55fead44.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "9e609414a58194f824ad8fef740ed12a",
    "url": "/Covid19-Peru/static/media/conversacion.9e609414.svg"
  },
  {
    "revision": "d7afa43e8273de4bcdf849423dceb20b",
    "url": "/Covid19-Peru/static/media/covid_19.d7afa43e.svg"
  },
  {
    "revision": "c64430b2948cadf3e67a1a01b8fb1f78",
    "url": "/Covid19-Peru/static/media/css-3.c64430b2.svg"
  },
  {
    "revision": "231a5fc81a7a78d0308dccd5cabecc6e",
    "url": "/Covid19-Peru/static/media/herramienta.231a5fc8.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "037f2a0625c78965d7d3a36547baca80",
    "url": "/Covid19-Peru/static/media/javascript.037f2a06.svg"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "5257bedaec6beae772b699f1e3fa6e74",
    "url": "/Covid19-Peru/static/media/reaccionar.5257beda.svg"
  }
]);