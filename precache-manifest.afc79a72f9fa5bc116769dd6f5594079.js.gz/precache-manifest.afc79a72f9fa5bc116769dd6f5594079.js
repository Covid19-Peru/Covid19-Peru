self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4b02fa315378849c7fa1be396c785ab3",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "4915402bb8c51bb57237",
    "url": "/Covid19-Peru/static/css/10.236d1f20.chunk.css"
  },
  {
    "revision": "f462a73d7186c5c8565d",
    "url": "/Covid19-Peru/static/css/11.3d32d9ea.chunk.css"
  },
  {
    "revision": "5fe34686ebfcb72874ee",
    "url": "/Covid19-Peru/static/css/12.b3abbe3d.chunk.css"
  },
  {
    "revision": "e35b58b8e0412643da71",
    "url": "/Covid19-Peru/static/css/3.69121389.chunk.css"
  },
  {
    "revision": "36f626513cadaea10e11",
    "url": "/Covid19-Peru/static/css/4.1c14f6f5.chunk.css"
  },
  {
    "revision": "824dccbb96ae5520ea27",
    "url": "/Covid19-Peru/static/css/6.cb88b805.chunk.css"
  },
  {
    "revision": "38e55e7743d881ce20cc",
    "url": "/Covid19-Peru/static/css/7.3d32d9ea.chunk.css"
  },
  {
    "revision": "8b89a0a39a27401a4daf",
    "url": "/Covid19-Peru/static/css/8.67d967f3.chunk.css"
  },
  {
    "revision": "14e24fd69b0072ac1931",
    "url": "/Covid19-Peru/static/css/main.df89a53d.chunk.css"
  },
  {
    "revision": "ad47209d93ddeae916f0",
    "url": "/Covid19-Peru/static/js/index.0.ebca6d45.production.chunk.min.js"
  },
  {
    "revision": "4915402bb8c51bb57237",
    "url": "/Covid19-Peru/static/js/index.10.4c1b8910.production.chunk.min.js"
  },
  {
    "revision": "f462a73d7186c5c8565d",
    "url": "/Covid19-Peru/static/js/index.11.7e996049.production.chunk.min.js"
  },
  {
    "revision": "5fe34686ebfcb72874ee",
    "url": "/Covid19-Peru/static/js/index.12.3367a039.production.chunk.min.js"
  },
  {
    "revision": "089134105e83c327d3af",
    "url": "/Covid19-Peru/static/js/index.13.73d8be30.production.chunk.min.js"
  },
  {
    "revision": "e35b58b8e0412643da71",
    "url": "/Covid19-Peru/static/js/index.3.04328026.production.chunk.min.js"
  },
  {
    "revision": "1cbc60dbad5345c0952e4bd6bd15d4b8",
    "url": "/Covid19-Peru/static/js/index.3.04328026.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "36f626513cadaea10e11",
    "url": "/Covid19-Peru/static/js/index.4.6299f7c1.production.chunk.min.js"
  },
  {
    "revision": "8bff3f64a6d423f4d732",
    "url": "/Covid19-Peru/static/js/index.4040933e.production.min.js"
  },
  {
    "revision": "bdecafca0cccc29995e0",
    "url": "/Covid19-Peru/static/js/index.5.67f378db.production.chunk.min.js"
  },
  {
    "revision": "824dccbb96ae5520ea27",
    "url": "/Covid19-Peru/static/js/index.6.ac248332.production.chunk.min.js"
  },
  {
    "revision": "38e55e7743d881ce20cc",
    "url": "/Covid19-Peru/static/js/index.7.1b29a667.production.chunk.min.js"
  },
  {
    "revision": "8b89a0a39a27401a4daf",
    "url": "/Covid19-Peru/static/js/index.8.952e2ee2.production.chunk.min.js"
  },
  {
    "revision": "c5b6e266c91edf0f74ff",
    "url": "/Covid19-Peru/static/js/index.9.be177735.production.chunk.min.js"
  },
  {
    "revision": "14e24fd69b0072ac1931",
    "url": "/Covid19-Peru/static/js/index.main.bc4cef4b.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "9e609414a58194f824ad8fef740ed12a",
    "url": "/Covid19-Peru/static/media/conversacion.9e609414.svg"
  },
  {
    "revision": "d7afa43e8273de4bcdf849423dceb20b",
    "url": "/Covid19-Peru/static/media/covid_19.d7afa43e.svg"
  },
  {
    "revision": "c64430b2948cadf3e67a1a01b8fb1f78",
    "url": "/Covid19-Peru/static/media/css-3.c64430b2.svg"
  },
  {
    "revision": "231a5fc81a7a78d0308dccd5cabecc6e",
    "url": "/Covid19-Peru/static/media/herramienta.231a5fc8.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "037f2a0625c78965d7d3a36547baca80",
    "url": "/Covid19-Peru/static/media/javascript.037f2a06.svg"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "5257bedaec6beae772b699f1e3fa6e74",
    "url": "/Covid19-Peru/static/media/reaccionar.5257beda.svg"
  }
]);