self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "79c8edde51ff11550c35943c37d7c7bd",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "8fa8861f9ef01ee44211",
    "url": "/Covid19-Peru/static/css/10.3d32d9ea.chunk.css"
  },
  {
    "revision": "9f0cf525eb2f8e9a57b9",
    "url": "/Covid19-Peru/static/css/11.3d32d9ea.chunk.css"
  },
  {
    "revision": "dd63b2c9e1a9b68e15dd",
    "url": "/Covid19-Peru/static/css/12.b3abbe3d.chunk.css"
  },
  {
    "revision": "c002865209864f65260a",
    "url": "/Covid19-Peru/static/css/4.75c4ecca.chunk.css"
  },
  {
    "revision": "6d92affed6976d414c4d",
    "url": "/Covid19-Peru/static/css/5.36193cd3.chunk.css"
  },
  {
    "revision": "922429e3bf3ce430ae33",
    "url": "/Covid19-Peru/static/css/7.83cc6039.chunk.css"
  },
  {
    "revision": "780f97bcfd3d714723c0",
    "url": "/Covid19-Peru/static/css/8.79ac54af.chunk.css"
  },
  {
    "revision": "cae6f3e1d6df4483d86c",
    "url": "/Covid19-Peru/static/css/9.bd83746a.chunk.css"
  },
  {
    "revision": "ea3d63163f74f29341f1",
    "url": "/Covid19-Peru/static/css/main.9524f553.chunk.css"
  },
  {
    "revision": "63a7833a09ccf67671e3",
    "url": "/Covid19-Peru/static/js/index.0.4ed9f40c.production.chunk.min.js"
  },
  {
    "revision": "8fa8861f9ef01ee44211",
    "url": "/Covid19-Peru/static/js/index.10.280b020b.production.chunk.min.js"
  },
  {
    "revision": "9f0cf525eb2f8e9a57b9",
    "url": "/Covid19-Peru/static/js/index.11.be402dbd.production.chunk.min.js"
  },
  {
    "revision": "dd63b2c9e1a9b68e15dd",
    "url": "/Covid19-Peru/static/js/index.12.4573eb2a.production.chunk.min.js"
  },
  {
    "revision": "7c469153d9bc2613d7d3",
    "url": "/Covid19-Peru/static/js/index.13.fa2b604f.production.chunk.min.js"
  },
  {
    "revision": "ad44be9e14e6d5e746d3",
    "url": "/Covid19-Peru/static/js/index.3.b35fc09d.production.chunk.min.js"
  },
  {
    "revision": "c002865209864f65260a",
    "url": "/Covid19-Peru/static/js/index.4.b1d281ea.production.chunk.min.js"
  },
  {
    "revision": "1cbc60dbad5345c0952e4bd6bd15d4b8",
    "url": "/Covid19-Peru/static/js/index.4.b1d281ea.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "6d92affed6976d414c4d",
    "url": "/Covid19-Peru/static/js/index.5.a3e287ce.production.chunk.min.js"
  },
  {
    "revision": "3dd175bc54dac85107c2",
    "url": "/Covid19-Peru/static/js/index.6.a1b4f134.production.chunk.min.js"
  },
  {
    "revision": "922429e3bf3ce430ae33",
    "url": "/Covid19-Peru/static/js/index.7.fc5a300b.production.chunk.min.js"
  },
  {
    "revision": "780f97bcfd3d714723c0",
    "url": "/Covid19-Peru/static/js/index.8.941e3f11.production.chunk.min.js"
  },
  {
    "revision": "cae6f3e1d6df4483d86c",
    "url": "/Covid19-Peru/static/js/index.9.f6587616.production.chunk.min.js"
  },
  {
    "revision": "01affdd2009b4df124cb",
    "url": "/Covid19-Peru/static/js/index.b56ace1b.production.min.js"
  },
  {
    "revision": "ea3d63163f74f29341f1",
    "url": "/Covid19-Peru/static/js/index.main.0392ee02.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "9e609414a58194f824ad8fef740ed12a",
    "url": "/Covid19-Peru/static/media/conversacion.9e609414.svg"
  },
  {
    "revision": "d7afa43e8273de4bcdf849423dceb20b",
    "url": "/Covid19-Peru/static/media/covid_19.d7afa43e.svg"
  },
  {
    "revision": "c64430b2948cadf3e67a1a01b8fb1f78",
    "url": "/Covid19-Peru/static/media/css-3.c64430b2.svg"
  },
  {
    "revision": "231a5fc81a7a78d0308dccd5cabecc6e",
    "url": "/Covid19-Peru/static/media/herramienta.231a5fc8.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "037f2a0625c78965d7d3a36547baca80",
    "url": "/Covid19-Peru/static/media/javascript.037f2a06.svg"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "5257bedaec6beae772b699f1e3fa6e74",
    "url": "/Covid19-Peru/static/media/reaccionar.5257beda.svg"
  }
]);