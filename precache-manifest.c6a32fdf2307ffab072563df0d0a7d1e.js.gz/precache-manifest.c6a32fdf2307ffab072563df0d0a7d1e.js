self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7f15fae060119ea0428faba2be762d99",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "9403eaf0930106f8a140",
    "url": "/Covid19-Peru/static/css/10.9202e915.chunk.css"
  },
  {
    "revision": "6877736056b313dee97d",
    "url": "/Covid19-Peru/static/css/11.9202e915.chunk.css"
  },
  {
    "revision": "abf996c2a914719eb006",
    "url": "/Covid19-Peru/static/css/4.de424728.chunk.css"
  },
  {
    "revision": "846620dc290836045f22",
    "url": "/Covid19-Peru/static/css/5.49f26715.chunk.css"
  },
  {
    "revision": "356f12e89b5695b6ffe6",
    "url": "/Covid19-Peru/static/css/6.14cc9829.chunk.css"
  },
  {
    "revision": "64e9ca919f1e9b904e5e",
    "url": "/Covid19-Peru/static/css/7.34468ac6.chunk.css"
  },
  {
    "revision": "23062483768af6ed285b",
    "url": "/Covid19-Peru/static/css/8.0aaac4c2.chunk.css"
  },
  {
    "revision": "d08918a93d14ded5e8ca",
    "url": "/Covid19-Peru/static/css/9.de8242ae.chunk.css"
  },
  {
    "revision": "c0fa6ac074af1ce606ce",
    "url": "/Covid19-Peru/static/js/index.0.027a1e35.production.chunk.min.js"
  },
  {
    "revision": "d8587303102136a17a0c",
    "url": "/Covid19-Peru/static/js/index.0f6de357.production.min.js"
  },
  {
    "revision": "52062e15753a4565ff66",
    "url": "/Covid19-Peru/static/js/index.1.c9e71078.production.chunk.min.js"
  },
  {
    "revision": "9403eaf0930106f8a140",
    "url": "/Covid19-Peru/static/js/index.10.7127e1a2.production.chunk.min.js"
  },
  {
    "revision": "6877736056b313dee97d",
    "url": "/Covid19-Peru/static/js/index.11.ce6fe3f4.production.chunk.min.js"
  },
  {
    "revision": "abf996c2a914719eb006",
    "url": "/Covid19-Peru/static/js/index.4.92461d64.production.chunk.min.js"
  },
  {
    "revision": "f231859d6585c4cd5f80c344783ed269",
    "url": "/Covid19-Peru/static/js/index.4.92461d64.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "846620dc290836045f22",
    "url": "/Covid19-Peru/static/js/index.5.524c171f.production.chunk.min.js"
  },
  {
    "revision": "356f12e89b5695b6ffe6",
    "url": "/Covid19-Peru/static/js/index.6.281684eb.production.chunk.min.js"
  },
  {
    "revision": "64e9ca919f1e9b904e5e",
    "url": "/Covid19-Peru/static/js/index.7.4e809ba1.production.chunk.min.js"
  },
  {
    "revision": "23062483768af6ed285b",
    "url": "/Covid19-Peru/static/js/index.8.19f3b22d.production.chunk.min.js"
  },
  {
    "revision": "d08918a93d14ded5e8ca",
    "url": "/Covid19-Peru/static/js/index.9.c58ceb2d.production.chunk.min.js"
  },
  {
    "revision": "8a0a393afb143574feac",
    "url": "/Covid19-Peru/static/js/index.main.04e338a1.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "2b56a4a4935a33ecef18e9543901a931",
    "url": "/Covid19-Peru/static/media/conversacion.2b56a4a4.svg"
  },
  {
    "revision": "6a2667fe962749da85b25a534c52244a",
    "url": "/Covid19-Peru/static/media/coronavirus192.6a2667fe.png"
  },
  {
    "revision": "2db97d69ba44f8da4663584e8197143f",
    "url": "/Covid19-Peru/static/media/css-3.2db97d69.svg"
  },
  {
    "revision": "700dba7024b41484270b6d1dc85d2f7d",
    "url": "/Covid19-Peru/static/media/facebook.700dba70.svg"
  },
  {
    "revision": "231a5fc81a7a78d0308dccd5cabecc6e",
    "url": "/Covid19-Peru/static/media/herramienta.231a5fc8.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "876e2cee5a6b9e5a0a0b429f0f760be9",
    "url": "/Covid19-Peru/static/media/icomoon.876e2cee.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "c90ed54c345f4ceadc6ec28bf046dda8",
    "url": "/Covid19-Peru/static/media/javascript.c90ed54c.svg"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "eab76719fd611cab5eecb1eb1427675a",
    "url": "/Covid19-Peru/static/media/reaccionar.eab76719.svg"
  },
  {
    "revision": "c9f1200836515fd4bacd29160be78732",
    "url": "/Covid19-Peru/static/media/twitter.c9f12008.svg"
  },
  {
    "revision": "a51ab7ed010a415170cd93a2a29d96dd",
    "url": "/Covid19-Peru/static/media/youtube.a51ab7ed.svg"
  }
]);