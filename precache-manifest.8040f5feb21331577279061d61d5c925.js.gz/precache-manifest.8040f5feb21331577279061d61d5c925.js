self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bc8c75441bac8b00e276707b38cfdab5",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "dbdb72c1b5b3e4b4c58c",
    "url": "/Covid19-Peru/static/css/10.413908a3.chunk.css"
  },
  {
    "revision": "995195ecafd4d9ed380e",
    "url": "/Covid19-Peru/static/css/11.413908a3.chunk.css"
  },
  {
    "revision": "c5884a4301cc0b7bdba7",
    "url": "/Covid19-Peru/static/css/4.3adc8b4e.chunk.css"
  },
  {
    "revision": "454505affd38d9e679cc",
    "url": "/Covid19-Peru/static/css/5.c26ab57c.chunk.css"
  },
  {
    "revision": "d63fc4a7718ca86cae1f",
    "url": "/Covid19-Peru/static/css/6.6af6fe55.chunk.css"
  },
  {
    "revision": "ab0c0fcaae9b83607e0f",
    "url": "/Covid19-Peru/static/css/7.67d967f3.chunk.css"
  },
  {
    "revision": "fd598978e507c29c3450",
    "url": "/Covid19-Peru/static/css/8.36193cd3.chunk.css"
  },
  {
    "revision": "758afd818848cf569da9",
    "url": "/Covid19-Peru/static/css/9.7bfb1717.chunk.css"
  },
  {
    "revision": "5cd052d90910e3ee0dd0",
    "url": "/Covid19-Peru/static/js/index.0.0235a46e.production.chunk.min.js"
  },
  {
    "revision": "4a9510009caeb48038e0",
    "url": "/Covid19-Peru/static/js/index.1.01af252d.production.chunk.min.js"
  },
  {
    "revision": "dbdb72c1b5b3e4b4c58c",
    "url": "/Covid19-Peru/static/js/index.10.1045a9cb.production.chunk.min.js"
  },
  {
    "revision": "995195ecafd4d9ed380e",
    "url": "/Covid19-Peru/static/js/index.11.14088754.production.chunk.min.js"
  },
  {
    "revision": "c5884a4301cc0b7bdba7",
    "url": "/Covid19-Peru/static/js/index.4.92461d64.production.chunk.min.js"
  },
  {
    "revision": "f231859d6585c4cd5f80c344783ed269",
    "url": "/Covid19-Peru/static/js/index.4.92461d64.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "454505affd38d9e679cc",
    "url": "/Covid19-Peru/static/js/index.5.189786b3.production.chunk.min.js"
  },
  {
    "revision": "d63fc4a7718ca86cae1f",
    "url": "/Covid19-Peru/static/js/index.6.a3fa42f6.production.chunk.min.js"
  },
  {
    "revision": "ab0c0fcaae9b83607e0f",
    "url": "/Covid19-Peru/static/js/index.7.a957968b.production.chunk.min.js"
  },
  {
    "revision": "fd598978e507c29c3450",
    "url": "/Covid19-Peru/static/js/index.8.19e9add7.production.chunk.min.js"
  },
  {
    "revision": "758afd818848cf569da9",
    "url": "/Covid19-Peru/static/js/index.9.16773e0b.production.chunk.min.js"
  },
  {
    "revision": "d20bc26f911c01d4a591",
    "url": "/Covid19-Peru/static/js/index.a3c74e31.production.min.js"
  },
  {
    "revision": "b018ec5a160176884650",
    "url": "/Covid19-Peru/static/js/index.main.32f635ec.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "9e609414a58194f824ad8fef740ed12a",
    "url": "/Covid19-Peru/static/media/conversacion.9e609414.svg"
  },
  {
    "revision": "6a2667fe962749da85b25a534c52244a",
    "url": "/Covid19-Peru/static/media/coronavirus192.6a2667fe.png"
  },
  {
    "revision": "700dba7024b41484270b6d1dc85d2f7d",
    "url": "/Covid19-Peru/static/media/facebook.700dba70.svg"
  },
  {
    "revision": "231a5fc81a7a78d0308dccd5cabecc6e",
    "url": "/Covid19-Peru/static/media/herramienta.231a5fc8.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "7a4d9f0fe157437d3258bbc3b785066d",
    "url": "/Covid19-Peru/static/media/twitter.7a4d9f0f.svg"
  },
  {
    "revision": "a51ab7ed010a415170cd93a2a29d96dd",
    "url": "/Covid19-Peru/static/media/youtube.a51ab7ed.svg"
  }
]);