self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4c79b40932376f41228ea151fa81c933",
    "url": "/index.html"
  },
  {
    "revision": "29d660a0485b0263381c",
    "url": "/static/css/10.33c0c49e.chunk.css"
  },
  {
    "revision": "9d9e55d2098e9716650c",
    "url": "/static/css/11.89c7d23c.chunk.css"
  },
  {
    "revision": "645e13ccda922b5a591a",
    "url": "/static/css/12.b3abbe3d.chunk.css"
  },
  {
    "revision": "3a76371f2309c228f93b",
    "url": "/static/css/3.69121389.chunk.css"
  },
  {
    "revision": "1f5e5787cd27f992814c",
    "url": "/static/css/4.1c14f6f5.chunk.css"
  },
  {
    "revision": "dd450f198f480f824288",
    "url": "/static/css/6.3795e40c.chunk.css"
  },
  {
    "revision": "667d2b5297d8d6f40e0e",
    "url": "/static/css/7.89c7d23c.chunk.css"
  },
  {
    "revision": "5b8797953b7a91bd5441",
    "url": "/static/css/8.67d967f3.chunk.css"
  },
  {
    "revision": "d5b9663621690b60743e",
    "url": "/static/css/main.df89a53d.chunk.css"
  },
  {
    "revision": "f8e0a7bdfc759a649ce0",
    "url": "/static/js/index.0.af20320b.production.chunk.min.js"
  },
  {
    "revision": "29d660a0485b0263381c",
    "url": "/static/js/index.10.acf04aa2.production.chunk.min.js"
  },
  {
    "revision": "9d9e55d2098e9716650c",
    "url": "/static/js/index.11.4cddc733.production.chunk.min.js"
  },
  {
    "revision": "645e13ccda922b5a591a",
    "url": "/static/js/index.12.bee7bda1.production.chunk.min.js"
  },
  {
    "revision": "43af690da842b6e4fb51",
    "url": "/static/js/index.13.2b0c7a84.production.chunk.min.js"
  },
  {
    "revision": "3a76371f2309c228f93b",
    "url": "/static/js/index.3.fb06fe80.production.chunk.min.js"
  },
  {
    "revision": "1cbc60dbad5345c0952e4bd6bd15d4b8",
    "url": "/static/js/index.3.fb06fe80.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "1f5e5787cd27f992814c",
    "url": "/static/js/index.4.a47afbca.production.chunk.min.js"
  },
  {
    "revision": "ead7139a63af12d98474",
    "url": "/static/js/index.5.cfa94ad4.production.chunk.min.js"
  },
  {
    "revision": "13851d7f0948c0fabffa",
    "url": "/static/js/index.5e4796b7.production.min.js"
  },
  {
    "revision": "dd450f198f480f824288",
    "url": "/static/js/index.6.89ce8e68.production.chunk.min.js"
  },
  {
    "revision": "667d2b5297d8d6f40e0e",
    "url": "/static/js/index.7.f5d62e75.production.chunk.min.js"
  },
  {
    "revision": "5b8797953b7a91bd5441",
    "url": "/static/js/index.8.9c83907d.production.chunk.min.js"
  },
  {
    "revision": "6a1c13ab5624346aa8df",
    "url": "/static/js/index.9.d79031a1.production.chunk.min.js"
  },
  {
    "revision": "d5b9663621690b60743e",
    "url": "/static/js/index.main.9e0b53da.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "9e609414a58194f824ad8fef740ed12a",
    "url": "/static/media/conversacion.9e609414.svg"
  },
  {
    "revision": "d7afa43e8273de4bcdf849423dceb20b",
    "url": "/static/media/covid_19.d7afa43e.svg"
  },
  {
    "revision": "c64430b2948cadf3e67a1a01b8fb1f78",
    "url": "/static/media/css-3.c64430b2.svg"
  },
  {
    "revision": "231a5fc81a7a78d0308dccd5cabecc6e",
    "url": "/static/media/herramienta.231a5fc8.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "037f2a0625c78965d7d3a36547baca80",
    "url": "/static/media/javascript.037f2a06.svg"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "5257bedaec6beae772b699f1e3fa6e74",
    "url": "/static/media/reaccionar.5257beda.svg"
  }
]);