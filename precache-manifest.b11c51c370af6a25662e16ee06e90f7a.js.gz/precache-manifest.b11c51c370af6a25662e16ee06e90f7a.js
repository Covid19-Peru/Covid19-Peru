self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4ecf86fbb09ed80bf19cf87ef0bb5959",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "a53497d64dd7727069b5",
    "url": "/Covid19-Peru/static/css/10.53de1025.chunk.css"
  },
  {
    "revision": "34af06d7fe7dec9cfd4e",
    "url": "/Covid19-Peru/static/css/11.53de1025.chunk.css"
  },
  {
    "revision": "dd63b2c9e1a9b68e15dd",
    "url": "/Covid19-Peru/static/css/12.b3abbe3d.chunk.css"
  },
  {
    "revision": "cf3f5c8dc8437f90099c",
    "url": "/Covid19-Peru/static/css/4.af3c1da9.chunk.css"
  },
  {
    "revision": "540f07a2d8de5b2a546c",
    "url": "/Covid19-Peru/static/css/5.36193cd3.chunk.css"
  },
  {
    "revision": "c40d60d1e4bd4bf03d2a",
    "url": "/Covid19-Peru/static/css/7.5d75b500.chunk.css"
  },
  {
    "revision": "780f97bcfd3d714723c0",
    "url": "/Covid19-Peru/static/css/8.79ac54af.chunk.css"
  },
  {
    "revision": "63a72adc8eb98a9c5bbb",
    "url": "/Covid19-Peru/static/css/9.36b41cd5.chunk.css"
  },
  {
    "revision": "519fa21bfc976a9fa8e6",
    "url": "/Covid19-Peru/static/css/main.9524f553.chunk.css"
  },
  {
    "revision": "63a7833a09ccf67671e3",
    "url": "/Covid19-Peru/static/js/index.0.4ed9f40c.production.chunk.min.js"
  },
  {
    "revision": "579f8cc87314a32425ec",
    "url": "/Covid19-Peru/static/js/index.0ef46ec3.production.min.js"
  },
  {
    "revision": "a53497d64dd7727069b5",
    "url": "/Covid19-Peru/static/js/index.10.280b020b.production.chunk.min.js"
  },
  {
    "revision": "34af06d7fe7dec9cfd4e",
    "url": "/Covid19-Peru/static/js/index.11.be402dbd.production.chunk.min.js"
  },
  {
    "revision": "dd63b2c9e1a9b68e15dd",
    "url": "/Covid19-Peru/static/js/index.12.4573eb2a.production.chunk.min.js"
  },
  {
    "revision": "7c469153d9bc2613d7d3",
    "url": "/Covid19-Peru/static/js/index.13.fa2b604f.production.chunk.min.js"
  },
  {
    "revision": "ad44be9e14e6d5e746d3",
    "url": "/Covid19-Peru/static/js/index.3.b35fc09d.production.chunk.min.js"
  },
  {
    "revision": "cf3f5c8dc8437f90099c",
    "url": "/Covid19-Peru/static/js/index.4.b1d281ea.production.chunk.min.js"
  },
  {
    "revision": "1cbc60dbad5345c0952e4bd6bd15d4b8",
    "url": "/Covid19-Peru/static/js/index.4.b1d281ea.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "540f07a2d8de5b2a546c",
    "url": "/Covid19-Peru/static/js/index.5.0454083b.production.chunk.min.js"
  },
  {
    "revision": "3dd175bc54dac85107c2",
    "url": "/Covid19-Peru/static/js/index.6.a1b4f134.production.chunk.min.js"
  },
  {
    "revision": "c40d60d1e4bd4bf03d2a",
    "url": "/Covid19-Peru/static/js/index.7.fc5a300b.production.chunk.min.js"
  },
  {
    "revision": "780f97bcfd3d714723c0",
    "url": "/Covid19-Peru/static/js/index.8.941e3f11.production.chunk.min.js"
  },
  {
    "revision": "63a72adc8eb98a9c5bbb",
    "url": "/Covid19-Peru/static/js/index.9.f6587616.production.chunk.min.js"
  },
  {
    "revision": "519fa21bfc976a9fa8e6",
    "url": "/Covid19-Peru/static/js/index.main.e61d9a71.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "49254deeaa11bfb370e1af7d1596e389",
    "url": "/Covid19-Peru/static/media/conversacion.49254dee.svg"
  },
  {
    "revision": "c413b8d1f879ca3e5197ffd0608ada0b",
    "url": "/Covid19-Peru/static/media/covid_19.c413b8d1.svg"
  },
  {
    "revision": "cc56234f0da6ca1734348703d458f0d4",
    "url": "/Covid19-Peru/static/media/css-3.cc56234f.svg"
  },
  {
    "revision": "01299d10d61febc8ed2714a056a731cf",
    "url": "/Covid19-Peru/static/media/herramienta.01299d10.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "c0753c5cec1cdc9f1f409e654387d015",
    "url": "/Covid19-Peru/static/media/icomoon.c0753c5c.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "90dc38ae8e44b5551b72ead1bf1d8860",
    "url": "/Covid19-Peru/static/media/javascript.90dc38ae.svg"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "4d0df56de3689b36f23c19e7cbcb709e",
    "url": "/Covid19-Peru/static/media/reaccionar.4d0df56d.svg"
  }
]);