self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "85e956e99f04303fce3c1a8db7c7bbb1",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "7c2baae7255e3662d519",
    "url": "/Covid19-Peru/static/css/3.3adc8b4e.chunk.css"
  },
  {
    "revision": "b7cc5a5a575bcca29877",
    "url": "/Covid19-Peru/static/css/4.1f365c88.chunk.css"
  },
  {
    "revision": "ecf89dba4d9ebcd7d1f3",
    "url": "/Covid19-Peru/static/css/5.523f045c.chunk.css"
  },
  {
    "revision": "e83e05143340e868d057",
    "url": "/Covid19-Peru/static/js/index.0.74022eac.production.chunk.min.js"
  },
  {
    "revision": "7c2baae7255e3662d519",
    "url": "/Covid19-Peru/static/js/index.3.ba7415d4.production.chunk.min.js"
  },
  {
    "revision": "f231859d6585c4cd5f80c344783ed269",
    "url": "/Covid19-Peru/static/js/index.3.ba7415d4.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "b7cc5a5a575bcca29877",
    "url": "/Covid19-Peru/static/js/index.4.b498757d.production.chunk.min.js"
  },
  {
    "revision": "ecf89dba4d9ebcd7d1f3",
    "url": "/Covid19-Peru/static/js/index.5.e710bf99.production.chunk.min.js"
  },
  {
    "revision": "16c2f5a363d8d2b16267",
    "url": "/Covid19-Peru/static/js/index.6.69508786.production.chunk.min.js"
  },
  {
    "revision": "f684321bfa9644f4417c",
    "url": "/Covid19-Peru/static/js/index.7.fb6bce23.production.chunk.min.js"
  },
  {
    "revision": "eb101871b812b8a19e40",
    "url": "/Covid19-Peru/static/js/index.8.6fbb0405.production.chunk.min.js"
  },
  {
    "revision": "9f7818f9f74fb64566de",
    "url": "/Covid19-Peru/static/js/index.f52fe837.production.min.js"
  },
  {
    "revision": "90a410a19a8dbb8131bd",
    "url": "/Covid19-Peru/static/js/index.main.cb7e80d1.production.chunk.min.js"
  },
  {
    "revision": "6a2667fe962749da85b25a534c52244a",
    "url": "/Covid19-Peru/static/media/coronavirus192.6a2667fe.png"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  },
  {
    "revision": "7a4d9f0fe157437d3258bbc3b785066d",
    "url": "/Covid19-Peru/static/media/twitter.7a4d9f0f.svg"
  },
  {
    "revision": "a51ab7ed010a415170cd93a2a29d96dd",
    "url": "/Covid19-Peru/static/media/youtube.a51ab7ed.svg"
  }
]);