self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2a75fe5709fe73be080aec6ceb2d151b",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "8fa8861f9ef01ee44211",
    "url": "/Covid19-Peru/static/css/10.3d32d9ea.chunk.css"
  },
  {
    "revision": "9f0cf525eb2f8e9a57b9",
    "url": "/Covid19-Peru/static/css/11.3d32d9ea.chunk.css"
  },
  {
    "revision": "dd63b2c9e1a9b68e15dd",
    "url": "/Covid19-Peru/static/css/12.b3abbe3d.chunk.css"
  },
  {
    "revision": "cf3f5c8dc8437f90099c",
    "url": "/Covid19-Peru/static/css/4.af3c1da9.chunk.css"
  },
  {
    "revision": "b74e19c54cac735f3783",
    "url": "/Covid19-Peru/static/css/5.36193cd3.chunk.css"
  },
  {
    "revision": "922429e3bf3ce430ae33",
    "url": "/Covid19-Peru/static/css/7.83cc6039.chunk.css"
  },
  {
    "revision": "780f97bcfd3d714723c0",
    "url": "/Covid19-Peru/static/css/8.79ac54af.chunk.css"
  },
  {
    "revision": "cae6f3e1d6df4483d86c",
    "url": "/Covid19-Peru/static/css/9.bd83746a.chunk.css"
  },
  {
    "revision": "faa16f0ada395f3c742c",
    "url": "/Covid19-Peru/static/css/main.9524f553.chunk.css"
  },
  {
    "revision": "63a7833a09ccf67671e3",
    "url": "/Covid19-Peru/static/js/index.0.4ed9f40c.production.chunk.min.js"
  },
  {
    "revision": "8fa8861f9ef01ee44211",
    "url": "/Covid19-Peru/static/js/index.10.280b020b.production.chunk.min.js"
  },
  {
    "revision": "9f0cf525eb2f8e9a57b9",
    "url": "/Covid19-Peru/static/js/index.11.be402dbd.production.chunk.min.js"
  },
  {
    "revision": "dd63b2c9e1a9b68e15dd",
    "url": "/Covid19-Peru/static/js/index.12.4573eb2a.production.chunk.min.js"
  },
  {
    "revision": "7c469153d9bc2613d7d3",
    "url": "/Covid19-Peru/static/js/index.13.fa2b604f.production.chunk.min.js"
  },
  {
    "revision": "ad44be9e14e6d5e746d3",
    "url": "/Covid19-Peru/static/js/index.3.b35fc09d.production.chunk.min.js"
  },
  {
    "revision": "cf3f5c8dc8437f90099c",
    "url": "/Covid19-Peru/static/js/index.4.b1d281ea.production.chunk.min.js"
  },
  {
    "revision": "1cbc60dbad5345c0952e4bd6bd15d4b8",
    "url": "/Covid19-Peru/static/js/index.4.b1d281ea.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "b74e19c54cac735f3783",
    "url": "/Covid19-Peru/static/js/index.5.c1901285.production.chunk.min.js"
  },
  {
    "revision": "3dd175bc54dac85107c2",
    "url": "/Covid19-Peru/static/js/index.6.a1b4f134.production.chunk.min.js"
  },
  {
    "revision": "922429e3bf3ce430ae33",
    "url": "/Covid19-Peru/static/js/index.7.fc5a300b.production.chunk.min.js"
  },
  {
    "revision": "780f97bcfd3d714723c0",
    "url": "/Covid19-Peru/static/js/index.8.941e3f11.production.chunk.min.js"
  },
  {
    "revision": "cae6f3e1d6df4483d86c",
    "url": "/Covid19-Peru/static/js/index.9.f6587616.production.chunk.min.js"
  },
  {
    "revision": "08c1c0b960ce2c21c950",
    "url": "/Covid19-Peru/static/js/index.fb50c1ea.production.min.js"
  },
  {
    "revision": "faa16f0ada395f3c742c",
    "url": "/Covid19-Peru/static/js/index.main.c97a7a09.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "9e86e12e1bd32f52826f14ca0ae8e05d",
    "url": "/Covid19-Peru/static/media/conversacion.9e86e12e.svg"
  },
  {
    "revision": "4004fc4e53848868f63f2ec9c312793c",
    "url": "/Covid19-Peru/static/media/covid_19.4004fc4e.svg"
  },
  {
    "revision": "cc56234f0da6ca1734348703d458f0d4",
    "url": "/Covid19-Peru/static/media/css-3.cc56234f.svg"
  },
  {
    "revision": "01299d10d61febc8ed2714a056a731cf",
    "url": "/Covid19-Peru/static/media/herramienta.01299d10.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "e81d69da28741ac1b51c6e4c15787eb5",
    "url": "/Covid19-Peru/static/media/javascript.e81d69da.svg"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "4d0df56de3689b36f23c19e7cbcb709e",
    "url": "/Covid19-Peru/static/media/reaccionar.4d0df56d.svg"
  }
]);