self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "247ec15b5dc741c66bc1d72c9d079a70",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "e589956aabd4e02b2570",
    "url": "/Covid19-Peru/static/css/5.3adc8b4e.chunk.css"
  },
  {
    "revision": "8ee70b9f3a4186692e67",
    "url": "/Covid19-Peru/static/js/index.0.ac4afe8a.production.chunk.min.js"
  },
  {
    "revision": "9119ae4291849886dd68",
    "url": "/Covid19-Peru/static/js/index.1.58f97602.production.chunk.min.js"
  },
  {
    "revision": "a0cc4f3f02e82c1a8aa4",
    "url": "/Covid19-Peru/static/js/index.4.b4f57d7b.production.chunk.min.js"
  },
  {
    "revision": "153c199157247fdeb311b54e338493ac",
    "url": "/Covid19-Peru/static/js/index.4.b4f57d7b.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "e589956aabd4e02b2570",
    "url": "/Covid19-Peru/static/js/index.5.c628c42f.production.chunk.min.js"
  },
  {
    "revision": "5356fa2f66e46e6c05e4cbe319ac7f1d",
    "url": "/Covid19-Peru/static/js/index.5.c628c42f.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "5e79c98d2f3f57690475",
    "url": "/Covid19-Peru/static/js/index.6.456e8be6.production.chunk.min.js"
  },
  {
    "revision": "761c5bf73f569d457b81",
    "url": "/Covid19-Peru/static/js/index.7.04fbfcea.production.chunk.min.js"
  },
  {
    "revision": "1c6fdb3d305bc44f5d6d",
    "url": "/Covid19-Peru/static/js/index.8.716aff93.production.chunk.min.js"
  },
  {
    "revision": "82f158d90d2bcc1fe8a7",
    "url": "/Covid19-Peru/static/js/index.9.c30abc9b.production.chunk.min.js"
  },
  {
    "revision": "e1ca99ca29296f8597f9",
    "url": "/Covid19-Peru/static/js/index.f213fb7e.production.min.js"
  },
  {
    "revision": "9aaec94455e1d2aee4e3",
    "url": "/Covid19-Peru/static/js/index.main.29123003.production.chunk.min.js"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  }
]);