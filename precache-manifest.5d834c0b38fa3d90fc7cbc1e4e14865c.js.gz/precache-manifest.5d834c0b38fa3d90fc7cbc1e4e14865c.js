self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "88a1d3d831e2ade24aa6950a4be6e3f8",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "0b2561dcf31e5bf9ee13",
    "url": "/Covid19-Peru/static/css/10.b3abbe3d.chunk.css"
  },
  {
    "revision": "8da20b2b17b33201afc8",
    "url": "/Covid19-Peru/static/css/11.3d32d9ea.chunk.css"
  },
  {
    "revision": "de750d6dc0e02fd7174f",
    "url": "/Covid19-Peru/static/css/12.3d32d9ea.chunk.css"
  },
  {
    "revision": "b4b5eefbe6c2ea4d4819",
    "url": "/Covid19-Peru/static/css/4.af3c1da9.chunk.css"
  },
  {
    "revision": "a622e6fa7e631576291a",
    "url": "/Covid19-Peru/static/css/5.36193cd3.chunk.css"
  },
  {
    "revision": "f07a3374994ad99ade07",
    "url": "/Covid19-Peru/static/css/7.83cc6039.chunk.css"
  },
  {
    "revision": "77225dd6f68b6dd35b47",
    "url": "/Covid19-Peru/static/css/8.79ac54af.chunk.css"
  },
  {
    "revision": "ca699f28f153b37c0182",
    "url": "/Covid19-Peru/static/css/9.bd83746a.chunk.css"
  },
  {
    "revision": "4ba955e5bebd08314839",
    "url": "/Covid19-Peru/static/css/main.9524f553.chunk.css"
  },
  {
    "revision": "4b2e4ec9cb57c4ccb788",
    "url": "/Covid19-Peru/static/js/index.0.8cd31df0.production.chunk.min.js"
  },
  {
    "revision": "0b2561dcf31e5bf9ee13",
    "url": "/Covid19-Peru/static/js/index.10.e39b8ad2.production.chunk.min.js"
  },
  {
    "revision": "8da20b2b17b33201afc8",
    "url": "/Covid19-Peru/static/js/index.11.b45e24d1.production.chunk.min.js"
  },
  {
    "revision": "de750d6dc0e02fd7174f",
    "url": "/Covid19-Peru/static/js/index.12.f9f1d553.production.chunk.min.js"
  },
  {
    "revision": "b81ba2fe4e8af4c4886e",
    "url": "/Covid19-Peru/static/js/index.13.56d0eacd.production.chunk.min.js"
  },
  {
    "revision": "8cfc499cfd71ab8fac4d",
    "url": "/Covid19-Peru/static/js/index.2219ac75.production.min.js"
  },
  {
    "revision": "18f3d5b73aefc1125f7a",
    "url": "/Covid19-Peru/static/js/index.3.d52c3764.production.chunk.min.js"
  },
  {
    "revision": "b4b5eefbe6c2ea4d4819",
    "url": "/Covid19-Peru/static/js/index.4.2a711842.production.chunk.min.js"
  },
  {
    "revision": "1cbc60dbad5345c0952e4bd6bd15d4b8",
    "url": "/Covid19-Peru/static/js/index.4.2a711842.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "a622e6fa7e631576291a",
    "url": "/Covid19-Peru/static/js/index.5.720cd846.production.chunk.min.js"
  },
  {
    "revision": "3e1b1ce43d72fb1e9b70",
    "url": "/Covid19-Peru/static/js/index.6.aba650c6.production.chunk.min.js"
  },
  {
    "revision": "f07a3374994ad99ade07",
    "url": "/Covid19-Peru/static/js/index.7.41092de7.production.chunk.min.js"
  },
  {
    "revision": "77225dd6f68b6dd35b47",
    "url": "/Covid19-Peru/static/js/index.8.7dab4de7.production.chunk.min.js"
  },
  {
    "revision": "ca699f28f153b37c0182",
    "url": "/Covid19-Peru/static/js/index.9.a3b451b8.production.chunk.min.js"
  },
  {
    "revision": "4ba955e5bebd08314839",
    "url": "/Covid19-Peru/static/js/index.main.69508cdb.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "00c5567167e425054ab8109b6c46f73e",
    "url": "/Covid19-Peru/static/media/cargando.00c55671.svg"
  },
  {
    "revision": "9e86e12e1bd32f52826f14ca0ae8e05d",
    "url": "/Covid19-Peru/static/media/conversacion.9e86e12e.svg"
  },
  {
    "revision": "4004fc4e53848868f63f2ec9c312793c",
    "url": "/Covid19-Peru/static/media/covid_19.4004fc4e.svg"
  },
  {
    "revision": "cc56234f0da6ca1734348703d458f0d4",
    "url": "/Covid19-Peru/static/media/css-3.cc56234f.svg"
  },
  {
    "revision": "01299d10d61febc8ed2714a056a731cf",
    "url": "/Covid19-Peru/static/media/herramienta.01299d10.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "e81d69da28741ac1b51c6e4c15787eb5",
    "url": "/Covid19-Peru/static/media/javascript.e81d69da.svg"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "4d0df56de3689b36f23c19e7cbcb709e",
    "url": "/Covid19-Peru/static/media/reaccionar.4d0df56d.svg"
  }
]);