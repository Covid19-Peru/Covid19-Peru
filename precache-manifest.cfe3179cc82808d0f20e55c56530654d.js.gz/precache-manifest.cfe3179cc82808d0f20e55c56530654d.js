self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8b496796078ad99589466d1494c5413d",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "7c2baae7255e3662d519",
    "url": "/Covid19-Peru/static/css/3.3adc8b4e.chunk.css"
  },
  {
    "revision": "53bfc01cd61c06b4863c",
    "url": "/Covid19-Peru/static/css/4.392f6277.chunk.css"
  },
  {
    "revision": "391d6b72b7480cbf3091",
    "url": "/Covid19-Peru/static/css/5.3adc8aae.chunk.css"
  },
  {
    "revision": "ad283da01b5f36be2fc2",
    "url": "/Covid19-Peru/static/css/6.978521ab.chunk.css"
  },
  {
    "revision": "5487db9d9e04ba65e901",
    "url": "/Covid19-Peru/static/css/7.413908a3.chunk.css"
  },
  {
    "revision": "9f62d48f90d740c4f2a2",
    "url": "/Covid19-Peru/static/css/8.413908a3.chunk.css"
  },
  {
    "revision": "a0b22e90a7fd4423b843",
    "url": "/Covid19-Peru/static/js/index.0.842ae402.production.chunk.min.js"
  },
  {
    "revision": "b53d0e7c97e13a0a8472",
    "url": "/Covid19-Peru/static/js/index.10.74f7375f.production.chunk.min.js"
  },
  {
    "revision": "176e0f0df0485743859e",
    "url": "/Covid19-Peru/static/js/index.11.fbc46b7a.production.chunk.min.js"
  },
  {
    "revision": "4b952b69b254a46f45dd",
    "url": "/Covid19-Peru/static/js/index.12.0d04bd32.production.chunk.min.js"
  },
  {
    "revision": "7c2baae7255e3662d519",
    "url": "/Covid19-Peru/static/js/index.3.ba7415d4.production.chunk.min.js"
  },
  {
    "revision": "f231859d6585c4cd5f80c344783ed269",
    "url": "/Covid19-Peru/static/js/index.3.ba7415d4.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "53bfc01cd61c06b4863c",
    "url": "/Covid19-Peru/static/js/index.4.9da4f64d.production.chunk.min.js"
  },
  {
    "revision": "391d6b72b7480cbf3091",
    "url": "/Covid19-Peru/static/js/index.5.fac27e7a.production.chunk.min.js"
  },
  {
    "revision": "8d5e677076ecc3f5fd3f",
    "url": "/Covid19-Peru/static/js/index.522eaaf4.production.min.js"
  },
  {
    "revision": "ad283da01b5f36be2fc2",
    "url": "/Covid19-Peru/static/js/index.6.16f3092b.production.chunk.min.js"
  },
  {
    "revision": "5487db9d9e04ba65e901",
    "url": "/Covid19-Peru/static/js/index.7.12767115.production.chunk.min.js"
  },
  {
    "revision": "9f62d48f90d740c4f2a2",
    "url": "/Covid19-Peru/static/js/index.8.d133f9b1.production.chunk.min.js"
  },
  {
    "revision": "b96b60bac2e31edec040",
    "url": "/Covid19-Peru/static/js/index.9.5749997a.production.chunk.min.js"
  },
  {
    "revision": "cbf1df7c10680b66daff",
    "url": "/Covid19-Peru/static/js/index.main.19fd9611.production.chunk.min.js"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "6a2667fe962749da85b25a534c52244a",
    "url": "/Covid19-Peru/static/media/coronavirus192.6a2667fe.png"
  },
  {
    "revision": "700dba7024b41484270b6d1dc85d2f7d",
    "url": "/Covid19-Peru/static/media/facebook.700dba70.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  },
  {
    "revision": "7a4d9f0fe157437d3258bbc3b785066d",
    "url": "/Covid19-Peru/static/media/twitter.7a4d9f0f.svg"
  },
  {
    "revision": "a51ab7ed010a415170cd93a2a29d96dd",
    "url": "/Covid19-Peru/static/media/youtube.a51ab7ed.svg"
  }
]);