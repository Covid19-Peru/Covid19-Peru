self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2e3692e242c1a7cef635e3e66e5db98d",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "f5740bea878aeb479d92",
    "url": "/Covid19-Peru/static/css/3.3adc8b4e.chunk.css"
  },
  {
    "revision": "a2a4f145f7190766e2cd",
    "url": "/Covid19-Peru/static/css/4.ea6584bd.chunk.css"
  },
  {
    "revision": "2eb55722d7707b816831",
    "url": "/Covid19-Peru/static/css/5.523f045c.chunk.css"
  },
  {
    "revision": "e83e05143340e868d057",
    "url": "/Covid19-Peru/static/js/index.0.74022eac.production.chunk.min.js"
  },
  {
    "revision": "f5740bea878aeb479d92",
    "url": "/Covid19-Peru/static/js/index.3.730e9d34.production.chunk.min.js"
  },
  {
    "revision": "f231859d6585c4cd5f80c344783ed269",
    "url": "/Covid19-Peru/static/js/index.3.730e9d34.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "a2a4f145f7190766e2cd",
    "url": "/Covid19-Peru/static/js/index.4.ed4fef4a.production.chunk.min.js"
  },
  {
    "revision": "2eb55722d7707b816831",
    "url": "/Covid19-Peru/static/js/index.5.f9880e05.production.chunk.min.js"
  },
  {
    "revision": "16c2f5a363d8d2b16267",
    "url": "/Covid19-Peru/static/js/index.6.69508786.production.chunk.min.js"
  },
  {
    "revision": "20305d2bd32ec0a55ef7",
    "url": "/Covid19-Peru/static/js/index.7.b4a2d1f7.production.chunk.min.js"
  },
  {
    "revision": "a307065efc1187e29919",
    "url": "/Covid19-Peru/static/js/index.b0dec46d.production.min.js"
  },
  {
    "revision": "e3c3846e0f974a09c660",
    "url": "/Covid19-Peru/static/js/index.main.36343ddc.production.chunk.min.js"
  },
  {
    "revision": "6a2667fe962749da85b25a534c52244a",
    "url": "/Covid19-Peru/static/media/coronavirus192.6a2667fe.png"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  },
  {
    "revision": "7a4d9f0fe157437d3258bbc3b785066d",
    "url": "/Covid19-Peru/static/media/twitter.7a4d9f0f.svg"
  },
  {
    "revision": "a51ab7ed010a415170cd93a2a29d96dd",
    "url": "/Covid19-Peru/static/media/youtube.a51ab7ed.svg"
  }
]);