self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fd9f8c3559822a0d9f7289cf980281b2",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "6aad001ad4c578d44b30",
    "url": "/Covid19-Peru/static/css/10.b3abbe3d.chunk.css"
  },
  {
    "revision": "773ba4994fd14068dbc4",
    "url": "/Covid19-Peru/static/css/11.b88355da.chunk.css"
  },
  {
    "revision": "6c8bb6a99654ce0d5959",
    "url": "/Covid19-Peru/static/css/12.b88355da.chunk.css"
  },
  {
    "revision": "35c3f2988a973dd53a56",
    "url": "/Covid19-Peru/static/css/4.3adc8b4e.chunk.css"
  },
  {
    "revision": "bdc1c7b228f20bc560a2",
    "url": "/Covid19-Peru/static/css/5.36193cd3.chunk.css"
  },
  {
    "revision": "79c894b09524f3cf8867",
    "url": "/Covid19-Peru/static/css/6.83237831.chunk.css"
  },
  {
    "revision": "f1a359ee8af7b777bb51",
    "url": "/Covid19-Peru/static/css/7.8989c793.chunk.css"
  },
  {
    "revision": "90b831b5967b11de3904",
    "url": "/Covid19-Peru/static/css/8.02db7aa9.chunk.css"
  },
  {
    "revision": "97724109280778714d81",
    "url": "/Covid19-Peru/static/css/9.ac83c7f2.chunk.css"
  },
  {
    "revision": "be38152a4c1093ba1331",
    "url": "/Covid19-Peru/static/css/main.df89a53d.chunk.css"
  },
  {
    "revision": "a27618ef8d3cdf39b45b",
    "url": "/Covid19-Peru/static/js/index.0.0e5e2b46.production.chunk.min.js"
  },
  {
    "revision": "d43d7670f8acb2ed2d59",
    "url": "/Covid19-Peru/static/js/index.1.6a573a3e.production.chunk.min.js"
  },
  {
    "revision": "6aad001ad4c578d44b30",
    "url": "/Covid19-Peru/static/js/index.10.e0d61f79.production.chunk.min.js"
  },
  {
    "revision": "773ba4994fd14068dbc4",
    "url": "/Covid19-Peru/static/js/index.11.851acd0a.production.chunk.min.js"
  },
  {
    "revision": "6c8bb6a99654ce0d5959",
    "url": "/Covid19-Peru/static/js/index.12.2e68fef8.production.chunk.min.js"
  },
  {
    "revision": "4a67937b61e443bdf492",
    "url": "/Covid19-Peru/static/js/index.13.943e7ed3.production.chunk.min.js"
  },
  {
    "revision": "43d78edc398e1427002c",
    "url": "/Covid19-Peru/static/js/index.14.312c5508.production.chunk.min.js"
  },
  {
    "revision": "35c3f2988a973dd53a56",
    "url": "/Covid19-Peru/static/js/index.4.1e393489.production.chunk.min.js"
  },
  {
    "revision": "5035c289b7f4237f99c5f07b46faf6d0",
    "url": "/Covid19-Peru/static/js/index.4.1e393489.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "bdc1c7b228f20bc560a2",
    "url": "/Covid19-Peru/static/js/index.5.f19c92b3.production.chunk.min.js"
  },
  {
    "revision": "79c894b09524f3cf8867",
    "url": "/Covid19-Peru/static/js/index.6.3f35d70a.production.chunk.min.js"
  },
  {
    "revision": "f1a359ee8af7b777bb51",
    "url": "/Covid19-Peru/static/js/index.7.24e61a2c.production.chunk.min.js"
  },
  {
    "revision": "90b831b5967b11de3904",
    "url": "/Covid19-Peru/static/js/index.8.50c20530.production.chunk.min.js"
  },
  {
    "revision": "cfcb7087e845f2c6c522",
    "url": "/Covid19-Peru/static/js/index.8f8d7704.production.min.js"
  },
  {
    "revision": "97724109280778714d81",
    "url": "/Covid19-Peru/static/js/index.9.bfeb60b3.production.chunk.min.js"
  },
  {
    "revision": "be38152a4c1093ba1331",
    "url": "/Covid19-Peru/static/js/index.main.809fd1e5.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "9e609414a58194f824ad8fef740ed12a",
    "url": "/Covid19-Peru/static/media/conversacion.9e609414.svg"
  },
  {
    "revision": "6a2667fe962749da85b25a534c52244a",
    "url": "/Covid19-Peru/static/media/coronavirus192.6a2667fe.png"
  },
  {
    "revision": "d7afa43e8273de4bcdf849423dceb20b",
    "url": "/Covid19-Peru/static/media/covid_19.d7afa43e.svg"
  },
  {
    "revision": "c64430b2948cadf3e67a1a01b8fb1f78",
    "url": "/Covid19-Peru/static/media/css-3.c64430b2.svg"
  },
  {
    "revision": "700dba7024b41484270b6d1dc85d2f7d",
    "url": "/Covid19-Peru/static/media/facebook.700dba70.svg"
  },
  {
    "revision": "231a5fc81a7a78d0308dccd5cabecc6e",
    "url": "/Covid19-Peru/static/media/herramienta.231a5fc8.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "037f2a0625c78965d7d3a36547baca80",
    "url": "/Covid19-Peru/static/media/javascript.037f2a06.svg"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "5257bedaec6beae772b699f1e3fa6e74",
    "url": "/Covid19-Peru/static/media/reaccionar.5257beda.svg"
  },
  {
    "revision": "7a4d9f0fe157437d3258bbc3b785066d",
    "url": "/Covid19-Peru/static/media/twitter.7a4d9f0f.svg"
  },
  {
    "revision": "a51ab7ed010a415170cd93a2a29d96dd",
    "url": "/Covid19-Peru/static/media/youtube.a51ab7ed.svg"
  }
]);