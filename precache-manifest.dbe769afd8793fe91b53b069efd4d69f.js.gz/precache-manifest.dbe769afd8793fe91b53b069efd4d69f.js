self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5bf3bc6cb27408216fbc6f3ceb62bae4",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "a7d94f4cd8e63a30b974",
    "url": "/Covid19-Peru/static/css/3.de424728.chunk.css"
  },
  {
    "revision": "f31461e163884db754ab",
    "url": "/Covid19-Peru/static/css/4.03696358.chunk.css"
  },
  {
    "revision": "b7c2a7a7a74d51c7070d",
    "url": "/Covid19-Peru/static/css/5.b36174aa.chunk.css"
  },
  {
    "revision": "7f2508276e5211e7b097",
    "url": "/Covid19-Peru/static/css/6.480268be.chunk.css"
  },
  {
    "revision": "a0b22e90a7fd4423b843",
    "url": "/Covid19-Peru/static/js/index.0.842ae402.production.chunk.min.js"
  },
  {
    "revision": "6135db794591e992b9c1",
    "url": "/Covid19-Peru/static/js/index.0babb7c6.production.min.js"
  },
  {
    "revision": "a7d94f4cd8e63a30b974",
    "url": "/Covid19-Peru/static/js/index.3.ba7415d4.production.chunk.min.js"
  },
  {
    "revision": "f231859d6585c4cd5f80c344783ed269",
    "url": "/Covid19-Peru/static/js/index.3.ba7415d4.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "f31461e163884db754ab",
    "url": "/Covid19-Peru/static/js/index.4.2e38cdc7.production.chunk.min.js"
  },
  {
    "revision": "b7c2a7a7a74d51c7070d",
    "url": "/Covid19-Peru/static/js/index.5.8af6bff3.production.chunk.min.js"
  },
  {
    "revision": "7f2508276e5211e7b097",
    "url": "/Covid19-Peru/static/js/index.6.f759b8b4.production.chunk.min.js"
  },
  {
    "revision": "dac8910a7600abe4804c",
    "url": "/Covid19-Peru/static/js/index.7.87b64ed2.production.chunk.min.js"
  },
  {
    "revision": "f46dad81ee2daa264c41",
    "url": "/Covid19-Peru/static/js/index.8.ddf0cbed.production.chunk.min.js"
  },
  {
    "revision": "cace80c01874ecff538b",
    "url": "/Covid19-Peru/static/js/index.main.22243088.production.chunk.min.js"
  },
  {
    "revision": "6a2667fe962749da85b25a534c52244a",
    "url": "/Covid19-Peru/static/media/coronavirus192.6a2667fe.png"
  },
  {
    "revision": "700dba7024b41484270b6d1dc85d2f7d",
    "url": "/Covid19-Peru/static/media/facebook.700dba70.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "876e2cee5a6b9e5a0a0b429f0f760be9",
    "url": "/Covid19-Peru/static/media/icomoon.876e2cee.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  },
  {
    "revision": "c9f1200836515fd4bacd29160be78732",
    "url": "/Covid19-Peru/static/media/twitter.c9f12008.svg"
  },
  {
    "revision": "a51ab7ed010a415170cd93a2a29d96dd",
    "url": "/Covid19-Peru/static/media/youtube.a51ab7ed.svg"
  }
]);