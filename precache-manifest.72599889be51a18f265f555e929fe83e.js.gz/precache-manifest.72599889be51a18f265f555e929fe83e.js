self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a88647624735474342945d8cd6bf863f",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "2d619b848cecefdc8078",
    "url": "/Covid19-Peru/static/css/10.236d1f20.chunk.css"
  },
  {
    "revision": "a4f2803f3407500580a6",
    "url": "/Covid19-Peru/static/css/11.3d32d9ea.chunk.css"
  },
  {
    "revision": "ede6e248b4ced2b4aad9",
    "url": "/Covid19-Peru/static/css/12.b3abbe3d.chunk.css"
  },
  {
    "revision": "55411348cf2f74eb2d18",
    "url": "/Covid19-Peru/static/css/3.69121389.chunk.css"
  },
  {
    "revision": "ac18af7fee83f1c67384",
    "url": "/Covid19-Peru/static/css/4.1c14f6f5.chunk.css"
  },
  {
    "revision": "544724d7cdd044b4c36e",
    "url": "/Covid19-Peru/static/css/6.cb88b805.chunk.css"
  },
  {
    "revision": "afd7b0e0fd462625c0c9",
    "url": "/Covid19-Peru/static/css/7.3d32d9ea.chunk.css"
  },
  {
    "revision": "76213940c168a48aa82f",
    "url": "/Covid19-Peru/static/css/8.67d967f3.chunk.css"
  },
  {
    "revision": "9cf870d1e38ab3b7e668",
    "url": "/Covid19-Peru/static/css/main.df89a53d.chunk.css"
  },
  {
    "revision": "ad47209d93ddeae916f0",
    "url": "/Covid19-Peru/static/js/index.0.ebca6d45.production.chunk.min.js"
  },
  {
    "revision": "2d619b848cecefdc8078",
    "url": "/Covid19-Peru/static/js/index.10.70f7cbbe.production.chunk.min.js"
  },
  {
    "revision": "a4f2803f3407500580a6",
    "url": "/Covid19-Peru/static/js/index.11.3f5ab17c.production.chunk.min.js"
  },
  {
    "revision": "ede6e248b4ced2b4aad9",
    "url": "/Covid19-Peru/static/js/index.12.2051bdf1.production.chunk.min.js"
  },
  {
    "revision": "089134105e83c327d3af",
    "url": "/Covid19-Peru/static/js/index.13.73d8be30.production.chunk.min.js"
  },
  {
    "revision": "55411348cf2f74eb2d18",
    "url": "/Covid19-Peru/static/js/index.3.7675e826.production.chunk.min.js"
  },
  {
    "revision": "1cbc60dbad5345c0952e4bd6bd15d4b8",
    "url": "/Covid19-Peru/static/js/index.3.7675e826.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "ac18af7fee83f1c67384",
    "url": "/Covid19-Peru/static/js/index.4.598a4872.production.chunk.min.js"
  },
  {
    "revision": "bdecafca0cccc29995e0",
    "url": "/Covid19-Peru/static/js/index.5.67f378db.production.chunk.min.js"
  },
  {
    "revision": "544724d7cdd044b4c36e",
    "url": "/Covid19-Peru/static/js/index.6.97f59635.production.chunk.min.js"
  },
  {
    "revision": "afd7b0e0fd462625c0c9",
    "url": "/Covid19-Peru/static/js/index.7.63efb714.production.chunk.min.js"
  },
  {
    "revision": "76213940c168a48aa82f",
    "url": "/Covid19-Peru/static/js/index.8.750017d0.production.chunk.min.js"
  },
  {
    "revision": "c5b6e266c91edf0f74ff",
    "url": "/Covid19-Peru/static/js/index.9.be177735.production.chunk.min.js"
  },
  {
    "revision": "c3dd24f29fe05a71b107",
    "url": "/Covid19-Peru/static/js/index.b749f482.production.min.js"
  },
  {
    "revision": "9cf870d1e38ab3b7e668",
    "url": "/Covid19-Peru/static/js/index.main.09637440.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "9e609414a58194f824ad8fef740ed12a",
    "url": "/Covid19-Peru/static/media/conversacion.9e609414.svg"
  },
  {
    "revision": "d7afa43e8273de4bcdf849423dceb20b",
    "url": "/Covid19-Peru/static/media/covid_19.d7afa43e.svg"
  },
  {
    "revision": "c64430b2948cadf3e67a1a01b8fb1f78",
    "url": "/Covid19-Peru/static/media/css-3.c64430b2.svg"
  },
  {
    "revision": "231a5fc81a7a78d0308dccd5cabecc6e",
    "url": "/Covid19-Peru/static/media/herramienta.231a5fc8.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "037f2a0625c78965d7d3a36547baca80",
    "url": "/Covid19-Peru/static/media/javascript.037f2a06.svg"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "5257bedaec6beae772b699f1e3fa6e74",
    "url": "/Covid19-Peru/static/media/reaccionar.5257beda.svg"
  }
]);