self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c36951fa84676c5c447e2be872dd9784",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "2175fc6f31dfdd14bf91",
    "url": "/Covid19-Peru/static/css/10.9202e915.chunk.css"
  },
  {
    "revision": "4cbba17d6538997e7e96",
    "url": "/Covid19-Peru/static/css/11.59eb921a.chunk.css"
  },
  {
    "revision": "abf996c2a914719eb006",
    "url": "/Covid19-Peru/static/css/4.de424728.chunk.css"
  },
  {
    "revision": "12d7da97dcd44ca782c8",
    "url": "/Covid19-Peru/static/css/5.418b4b94.chunk.css"
  },
  {
    "revision": "649715fb1502bd2c9fc2",
    "url": "/Covid19-Peru/static/css/6.e7f7d8e1.chunk.css"
  },
  {
    "revision": "bfec5b6f5afcb270f877",
    "url": "/Covid19-Peru/static/css/7.03696358.chunk.css"
  },
  {
    "revision": "2f8c8110d79da5deb8b2",
    "url": "/Covid19-Peru/static/css/8.80af2923.chunk.css"
  },
  {
    "revision": "37bcba0119b37db184ba",
    "url": "/Covid19-Peru/static/css/9.9202e915.chunk.css"
  },
  {
    "revision": "391feca43b444ec80448",
    "url": "/Covid19-Peru/static/js/index.0.93717a2c.production.chunk.min.js"
  },
  {
    "revision": "4064babf74234308a194",
    "url": "/Covid19-Peru/static/js/index.1.667a6008.production.chunk.min.js"
  },
  {
    "revision": "2175fc6f31dfdd14bf91",
    "url": "/Covid19-Peru/static/js/index.10.560d9247.production.chunk.min.js"
  },
  {
    "revision": "4cbba17d6538997e7e96",
    "url": "/Covid19-Peru/static/js/index.11.742707ef.production.chunk.min.js"
  },
  {
    "revision": "7a45c3669896d29b1e9e",
    "url": "/Covid19-Peru/static/js/index.12.25323866.production.chunk.min.js"
  },
  {
    "revision": "abf996c2a914719eb006",
    "url": "/Covid19-Peru/static/js/index.4.92461d64.production.chunk.min.js"
  },
  {
    "revision": "f231859d6585c4cd5f80c344783ed269",
    "url": "/Covid19-Peru/static/js/index.4.92461d64.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "12d7da97dcd44ca782c8",
    "url": "/Covid19-Peru/static/js/index.5.c0a7b94f.production.chunk.min.js"
  },
  {
    "revision": "649715fb1502bd2c9fc2",
    "url": "/Covid19-Peru/static/js/index.6.0d47a0fd.production.chunk.min.js"
  },
  {
    "revision": "bfec5b6f5afcb270f877",
    "url": "/Covid19-Peru/static/js/index.7.f504c431.production.chunk.min.js"
  },
  {
    "revision": "2f8c8110d79da5deb8b2",
    "url": "/Covid19-Peru/static/js/index.8.c468bc19.production.chunk.min.js"
  },
  {
    "revision": "6d35595e0aa0d78228cb",
    "url": "/Covid19-Peru/static/js/index.8ae4f42f.production.min.js"
  },
  {
    "revision": "37bcba0119b37db184ba",
    "url": "/Covid19-Peru/static/js/index.9.0611300f.production.chunk.min.js"
  },
  {
    "revision": "14a571d12198f4c616ed",
    "url": "/Covid19-Peru/static/js/index.main.9f8fb182.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "6a2667fe962749da85b25a534c52244a",
    "url": "/Covid19-Peru/static/media/coronavirus192.6a2667fe.png"
  },
  {
    "revision": "700dba7024b41484270b6d1dc85d2f7d",
    "url": "/Covid19-Peru/static/media/facebook.700dba70.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "876e2cee5a6b9e5a0a0b429f0f760be9",
    "url": "/Covid19-Peru/static/media/icomoon.876e2cee.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "c9f1200836515fd4bacd29160be78732",
    "url": "/Covid19-Peru/static/media/twitter.c9f12008.svg"
  },
  {
    "revision": "a51ab7ed010a415170cd93a2a29d96dd",
    "url": "/Covid19-Peru/static/media/youtube.a51ab7ed.svg"
  }
]);