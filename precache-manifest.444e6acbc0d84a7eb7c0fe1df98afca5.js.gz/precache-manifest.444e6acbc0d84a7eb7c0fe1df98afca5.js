self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d83ee24b68667fc00e53b05aef76efe8",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "3e32c230dfe304c24d97",
    "url": "/Covid19-Peru/static/css/2.3adc8b4e.chunk.css"
  },
  {
    "revision": "3e32c230dfe304c24d97",
    "url": "/Covid19-Peru/static/js/index.2.3ea59f56.production.chunk.min.js"
  },
  {
    "revision": "5356fa2f66e46e6c05e4cbe319ac7f1d",
    "url": "/Covid19-Peru/static/js/index.2.3ea59f56.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "1d3bf0f38a77a27ad67b",
    "url": "/Covid19-Peru/static/js/index.b92acf85.production.min.js"
  },
  {
    "revision": "f89feb1cf86413a797a3",
    "url": "/Covid19-Peru/static/js/index.main.fae65eef.production.chunk.min.js"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  }
]);