self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e61372fdc897d1f449fbde616cd16366",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "cbb1fa60c8e4a7862d80",
    "url": "/Covid19-Peru/static/css/10.413908a3.chunk.css"
  },
  {
    "revision": "615a2eb60b90a9e09c8c",
    "url": "/Covid19-Peru/static/css/11.4fa58a3b.chunk.css"
  },
  {
    "revision": "c5884a4301cc0b7bdba7",
    "url": "/Covid19-Peru/static/css/4.3adc8b4e.chunk.css"
  },
  {
    "revision": "ddab18842bdea0f12612",
    "url": "/Covid19-Peru/static/css/5.d5fee35f.chunk.css"
  },
  {
    "revision": "8cf03534ee71358fb2b8",
    "url": "/Covid19-Peru/static/css/6.389874f5.chunk.css"
  },
  {
    "revision": "ec2c652cc5db6595cb4b",
    "url": "/Covid19-Peru/static/css/7.27586878.chunk.css"
  },
  {
    "revision": "e1da2f00c0afa258cef4",
    "url": "/Covid19-Peru/static/css/8.3adc8aae.chunk.css"
  },
  {
    "revision": "53cad2f111f4874101a5",
    "url": "/Covid19-Peru/static/css/9.413908a3.chunk.css"
  },
  {
    "revision": "869673553e706947e545",
    "url": "/Covid19-Peru/static/js/index.0.71de7c11.production.chunk.min.js"
  },
  {
    "revision": "16a5c9fdf481eebba63f",
    "url": "/Covid19-Peru/static/js/index.1.2730153d.production.chunk.min.js"
  },
  {
    "revision": "cbb1fa60c8e4a7862d80",
    "url": "/Covid19-Peru/static/js/index.10.e5e2c7c9.production.chunk.min.js"
  },
  {
    "revision": "615a2eb60b90a9e09c8c",
    "url": "/Covid19-Peru/static/js/index.11.bc0b3264.production.chunk.min.js"
  },
  {
    "revision": "040c781511e76519b3bb",
    "url": "/Covid19-Peru/static/js/index.12.4e803f03.production.chunk.min.js"
  },
  {
    "revision": "c5884a4301cc0b7bdba7",
    "url": "/Covid19-Peru/static/js/index.4.92461d64.production.chunk.min.js"
  },
  {
    "revision": "f231859d6585c4cd5f80c344783ed269",
    "url": "/Covid19-Peru/static/js/index.4.92461d64.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "ddab18842bdea0f12612",
    "url": "/Covid19-Peru/static/js/index.5.1dab00f0.production.chunk.min.js"
  },
  {
    "revision": "8cf03534ee71358fb2b8",
    "url": "/Covid19-Peru/static/js/index.6.b75e0aa2.production.chunk.min.js"
  },
  {
    "revision": "ec2c652cc5db6595cb4b",
    "url": "/Covid19-Peru/static/js/index.7.0ad9c105.production.chunk.min.js"
  },
  {
    "revision": "e1da2f00c0afa258cef4",
    "url": "/Covid19-Peru/static/js/index.8.937daae3.production.chunk.min.js"
  },
  {
    "revision": "53cad2f111f4874101a5",
    "url": "/Covid19-Peru/static/js/index.9.f5119649.production.chunk.min.js"
  },
  {
    "revision": "1d669ba8b66d44d97861",
    "url": "/Covid19-Peru/static/js/index.a9db1258.production.min.js"
  },
  {
    "revision": "a3b0f6daeca86837d8f9",
    "url": "/Covid19-Peru/static/js/index.main.fb4ed571.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "6a2667fe962749da85b25a534c52244a",
    "url": "/Covid19-Peru/static/media/coronavirus192.6a2667fe.png"
  },
  {
    "revision": "700dba7024b41484270b6d1dc85d2f7d",
    "url": "/Covid19-Peru/static/media/facebook.700dba70.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "7a4d9f0fe157437d3258bbc3b785066d",
    "url": "/Covid19-Peru/static/media/twitter.7a4d9f0f.svg"
  },
  {
    "revision": "a51ab7ed010a415170cd93a2a29d96dd",
    "url": "/Covid19-Peru/static/media/youtube.a51ab7ed.svg"
  }
]);