self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "596d35382e9bdcf3b35bd4814fba5031",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "771348fd756eed0c7508",
    "url": "/Covid19-Peru/static/css/4.3adc8b4e.chunk.css"
  },
  {
    "revision": "43a69eca8ce47aebdfd7",
    "url": "/Covid19-Peru/static/js/index.0.f544b7b5.production.chunk.min.js"
  },
  {
    "revision": "6f44bd7d1508d86cb411",
    "url": "/Covid19-Peru/static/js/index.3.a987485b.production.chunk.min.js"
  },
  {
    "revision": "153c199157247fdeb311b54e338493ac",
    "url": "/Covid19-Peru/static/js/index.3.a987485b.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "771348fd756eed0c7508",
    "url": "/Covid19-Peru/static/js/index.4.46ff9c95.production.chunk.min.js"
  },
  {
    "revision": "5356fa2f66e46e6c05e4cbe319ac7f1d",
    "url": "/Covid19-Peru/static/js/index.4.46ff9c95.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "5de8eefef39cceea2037",
    "url": "/Covid19-Peru/static/js/index.5.fab93d77.production.chunk.min.js"
  },
  {
    "revision": "7513e809eaebfa716576",
    "url": "/Covid19-Peru/static/js/index.6.6de70c83.production.chunk.min.js"
  },
  {
    "revision": "51929c9171a390f0fb10",
    "url": "/Covid19-Peru/static/js/index.7.b9c31067.production.chunk.min.js"
  },
  {
    "revision": "ef4bafb227c7558d970c",
    "url": "/Covid19-Peru/static/js/index.8.0c32f0bd.production.chunk.min.js"
  },
  {
    "revision": "f56d5cc64f65daadd108",
    "url": "/Covid19-Peru/static/js/index.d11002d4.production.min.js"
  },
  {
    "revision": "888925814faa04c4a9bc",
    "url": "/Covid19-Peru/static/js/index.main.4e0f5a29.production.chunk.min.js"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  }
]);