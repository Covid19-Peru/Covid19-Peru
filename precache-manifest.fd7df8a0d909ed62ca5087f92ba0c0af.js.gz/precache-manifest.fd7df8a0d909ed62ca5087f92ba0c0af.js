self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ba417a64f2eb817b494125c0b0fa31c8",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "4d3a59dd0bee4a9e703a",
    "url": "/Covid19-Peru/static/css/10.3d32d9ea.chunk.css"
  },
  {
    "revision": "7a0f404de191e7570f61",
    "url": "/Covid19-Peru/static/css/11.b3abbe3d.chunk.css"
  },
  {
    "revision": "31abadd0b57f844fdbfc",
    "url": "/Covid19-Peru/static/css/3.3adc8b4e.chunk.css"
  },
  {
    "revision": "c60ca28bbe18f326f039",
    "url": "/Covid19-Peru/static/css/4.236d1f20.chunk.css"
  },
  {
    "revision": "30b9ab28d1aa786510fc",
    "url": "/Covid19-Peru/static/css/5.36193cd3.chunk.css"
  },
  {
    "revision": "4a6ba632663e4ee871a9",
    "url": "/Covid19-Peru/static/css/6.cb88b805.chunk.css"
  },
  {
    "revision": "ff67806e53deb6eca2c1",
    "url": "/Covid19-Peru/static/css/7.3d32d9ea.chunk.css"
  },
  {
    "revision": "7e304305e02767cd3547",
    "url": "/Covid19-Peru/static/css/8.67d967f3.chunk.css"
  },
  {
    "revision": "28c6b2515d82d1cbc9aa",
    "url": "/Covid19-Peru/static/css/main.df89a53d.chunk.css"
  },
  {
    "revision": "5fb922129ef2740b6a44",
    "url": "/Covid19-Peru/static/js/index.0.7f2c4336.production.chunk.min.js"
  },
  {
    "revision": "4d3a59dd0bee4a9e703a",
    "url": "/Covid19-Peru/static/js/index.10.8498d9ce.production.chunk.min.js"
  },
  {
    "revision": "7a0f404de191e7570f61",
    "url": "/Covid19-Peru/static/js/index.11.8453a591.production.chunk.min.js"
  },
  {
    "revision": "775638c5b61ea27e3159",
    "url": "/Covid19-Peru/static/js/index.12.0d4528db.production.chunk.min.js"
  },
  {
    "revision": "31abadd0b57f844fdbfc",
    "url": "/Covid19-Peru/static/js/index.3.e0052067.production.chunk.min.js"
  },
  {
    "revision": "5035c289b7f4237f99c5f07b46faf6d0",
    "url": "/Covid19-Peru/static/js/index.3.e0052067.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "c60ca28bbe18f326f039",
    "url": "/Covid19-Peru/static/js/index.4.58665811.production.chunk.min.js"
  },
  {
    "revision": "30b9ab28d1aa786510fc",
    "url": "/Covid19-Peru/static/js/index.5.ddf97fc9.production.chunk.min.js"
  },
  {
    "revision": "4a6ba632663e4ee871a9",
    "url": "/Covid19-Peru/static/js/index.6.aef2fbbb.production.chunk.min.js"
  },
  {
    "revision": "ff67806e53deb6eca2c1",
    "url": "/Covid19-Peru/static/js/index.7.65b3d0bf.production.chunk.min.js"
  },
  {
    "revision": "7e304305e02767cd3547",
    "url": "/Covid19-Peru/static/js/index.8.9b0b0ecf.production.chunk.min.js"
  },
  {
    "revision": "31b151a184ae743ef17c",
    "url": "/Covid19-Peru/static/js/index.9.a30d035e.production.chunk.min.js"
  },
  {
    "revision": "f46164f4799e3ce34719",
    "url": "/Covid19-Peru/static/js/index.e3094be2.production.min.js"
  },
  {
    "revision": "28c6b2515d82d1cbc9aa",
    "url": "/Covid19-Peru/static/js/index.main.7b67b892.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "9e609414a58194f824ad8fef740ed12a",
    "url": "/Covid19-Peru/static/media/conversacion.9e609414.svg"
  },
  {
    "revision": "d7afa43e8273de4bcdf849423dceb20b",
    "url": "/Covid19-Peru/static/media/covid_19.d7afa43e.svg"
  },
  {
    "revision": "c64430b2948cadf3e67a1a01b8fb1f78",
    "url": "/Covid19-Peru/static/media/css-3.c64430b2.svg"
  },
  {
    "revision": "231a5fc81a7a78d0308dccd5cabecc6e",
    "url": "/Covid19-Peru/static/media/herramienta.231a5fc8.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "037f2a0625c78965d7d3a36547baca80",
    "url": "/Covid19-Peru/static/media/javascript.037f2a06.svg"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "5257bedaec6beae772b699f1e3fa6e74",
    "url": "/Covid19-Peru/static/media/reaccionar.5257beda.svg"
  }
]);