self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "539016fa6d0b8ebeb7329f273bd063f8",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "ab2328833042b675803c",
    "url": "/Covid19-Peru/static/css/3.3adc8b4e.chunk.css"
  },
  {
    "revision": "bd5909692f9e768eeab8",
    "url": "/Covid19-Peru/static/js/index.0.985c1a4d.production.chunk.min.js"
  },
  {
    "revision": "ab2328833042b675803c",
    "url": "/Covid19-Peru/static/js/index.3.e8e2b6b8.production.chunk.min.js"
  },
  {
    "revision": "f231859d6585c4cd5f80c344783ed269",
    "url": "/Covid19-Peru/static/js/index.3.e8e2b6b8.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "2dd2cf7b7816b73af1ad",
    "url": "/Covid19-Peru/static/js/index.4.f5928f40.production.chunk.min.js"
  },
  {
    "revision": "e878bed5150d5bc73edd",
    "url": "/Covid19-Peru/static/js/index.5.dc34a051.production.chunk.min.js"
  },
  {
    "revision": "cf1a45613e5fd9491488",
    "url": "/Covid19-Peru/static/js/index.6.eed85cab.production.chunk.min.js"
  },
  {
    "revision": "7fd9a1387ef7dd768675",
    "url": "/Covid19-Peru/static/js/index.7.2cc9d4c1.production.chunk.min.js"
  },
  {
    "revision": "5f7c4ee8d62ab2e21954",
    "url": "/Covid19-Peru/static/js/index.a6a28be0.production.min.js"
  },
  {
    "revision": "3852a60fd87fb6c4a0d0",
    "url": "/Covid19-Peru/static/js/index.main.bc615304.production.chunk.min.js"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  }
]);