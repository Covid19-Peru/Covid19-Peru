self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0e901c874b693ca7888a19b7d2dab95f",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "f5740bea878aeb479d92",
    "url": "/Covid19-Peru/static/css/3.3adc8b4e.chunk.css"
  },
  {
    "revision": "bd5909692f9e768eeab8",
    "url": "/Covid19-Peru/static/js/index.0.985c1a4d.production.chunk.min.js"
  },
  {
    "revision": "f5740bea878aeb479d92",
    "url": "/Covid19-Peru/static/js/index.3.730e9d34.production.chunk.min.js"
  },
  {
    "revision": "f231859d6585c4cd5f80c344783ed269",
    "url": "/Covid19-Peru/static/js/index.3.730e9d34.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "2dd2cf7b7816b73af1ad",
    "url": "/Covid19-Peru/static/js/index.4.f5928f40.production.chunk.min.js"
  },
  {
    "revision": "e878bed5150d5bc73edd",
    "url": "/Covid19-Peru/static/js/index.5.dc34a051.production.chunk.min.js"
  },
  {
    "revision": "cf1a45613e5fd9491488",
    "url": "/Covid19-Peru/static/js/index.6.eed85cab.production.chunk.min.js"
  },
  {
    "revision": "7468708da04be84e3211",
    "url": "/Covid19-Peru/static/js/index.7.65ed8188.production.chunk.min.js"
  },
  {
    "revision": "9745a200d43b074f3526",
    "url": "/Covid19-Peru/static/js/index.e53fee55.production.min.js"
  },
  {
    "revision": "6cee21ddeccf630cd570",
    "url": "/Covid19-Peru/static/js/index.main.f60f671e.production.chunk.min.js"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/Covid19-Peru/static/media/logo.94958d24.svg"
  }
]);