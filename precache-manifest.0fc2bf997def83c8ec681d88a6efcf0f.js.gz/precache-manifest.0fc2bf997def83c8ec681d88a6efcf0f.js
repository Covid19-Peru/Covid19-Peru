self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3e49d6783caa5b9dd838c3f9658959a9",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "51ac919f4dc54b864ba5",
    "url": "/Covid19-Peru/static/css/10.3d32d9ea.chunk.css"
  },
  {
    "revision": "0048f8929bd9e4ce426f",
    "url": "/Covid19-Peru/static/css/11.b3abbe3d.chunk.css"
  },
  {
    "revision": "d5eea8e1d4b4c1343e3c",
    "url": "/Covid19-Peru/static/css/3.3adc8b4e.chunk.css"
  },
  {
    "revision": "32c86d03866edeee4b0b",
    "url": "/Covid19-Peru/static/css/4.236d1f20.chunk.css"
  },
  {
    "revision": "6031e1a01fbea4885d23",
    "url": "/Covid19-Peru/static/css/5.36193cd3.chunk.css"
  },
  {
    "revision": "dc93e9f4a498e3a36964",
    "url": "/Covid19-Peru/static/css/6.cb88b805.chunk.css"
  },
  {
    "revision": "d0c0a8bdb6d6d9812745",
    "url": "/Covid19-Peru/static/css/7.3d32d9ea.chunk.css"
  },
  {
    "revision": "fb50dbe4ada2c0045aff",
    "url": "/Covid19-Peru/static/css/8.67d967f3.chunk.css"
  },
  {
    "revision": "bbbb62602c4a17507a68",
    "url": "/Covid19-Peru/static/css/main.df89a53d.chunk.css"
  },
  {
    "revision": "f698455ec7db741862b8",
    "url": "/Covid19-Peru/static/js/index.0.31d084b5.production.chunk.min.js"
  },
  {
    "revision": "29db452af0e419e90764",
    "url": "/Covid19-Peru/static/js/index.0bbfc223.production.min.js"
  },
  {
    "revision": "51ac919f4dc54b864ba5",
    "url": "/Covid19-Peru/static/js/index.10.7f1643dd.production.chunk.min.js"
  },
  {
    "revision": "0048f8929bd9e4ce426f",
    "url": "/Covid19-Peru/static/js/index.11.468c33bf.production.chunk.min.js"
  },
  {
    "revision": "ed0503390804e9d72cfe",
    "url": "/Covid19-Peru/static/js/index.12.86db4c83.production.chunk.min.js"
  },
  {
    "revision": "d5eea8e1d4b4c1343e3c",
    "url": "/Covid19-Peru/static/js/index.3.60e1d24c.production.chunk.min.js"
  },
  {
    "revision": "5035c289b7f4237f99c5f07b46faf6d0",
    "url": "/Covid19-Peru/static/js/index.3.60e1d24c.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "32c86d03866edeee4b0b",
    "url": "/Covid19-Peru/static/js/index.4.c96e9b7e.production.chunk.min.js"
  },
  {
    "revision": "6031e1a01fbea4885d23",
    "url": "/Covid19-Peru/static/js/index.5.ef7408bd.production.chunk.min.js"
  },
  {
    "revision": "dc93e9f4a498e3a36964",
    "url": "/Covid19-Peru/static/js/index.6.60de0da0.production.chunk.min.js"
  },
  {
    "revision": "d0c0a8bdb6d6d9812745",
    "url": "/Covid19-Peru/static/js/index.7.a7fc6689.production.chunk.min.js"
  },
  {
    "revision": "fb50dbe4ada2c0045aff",
    "url": "/Covid19-Peru/static/js/index.8.07f50b78.production.chunk.min.js"
  },
  {
    "revision": "491b1eea59c758b67b28",
    "url": "/Covid19-Peru/static/js/index.9.dcf3c320.production.chunk.min.js"
  },
  {
    "revision": "bbbb62602c4a17507a68",
    "url": "/Covid19-Peru/static/js/index.main.b8724266.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "9e609414a58194f824ad8fef740ed12a",
    "url": "/Covid19-Peru/static/media/conversacion.9e609414.svg"
  },
  {
    "revision": "d7afa43e8273de4bcdf849423dceb20b",
    "url": "/Covid19-Peru/static/media/covid_19.d7afa43e.svg"
  },
  {
    "revision": "c64430b2948cadf3e67a1a01b8fb1f78",
    "url": "/Covid19-Peru/static/media/css-3.c64430b2.svg"
  },
  {
    "revision": "231a5fc81a7a78d0308dccd5cabecc6e",
    "url": "/Covid19-Peru/static/media/herramienta.231a5fc8.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "037f2a0625c78965d7d3a36547baca80",
    "url": "/Covid19-Peru/static/media/javascript.037f2a06.svg"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "5257bedaec6beae772b699f1e3fa6e74",
    "url": "/Covid19-Peru/static/media/reaccionar.5257beda.svg"
  }
]);