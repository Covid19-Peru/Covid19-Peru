self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d90307ddf85466a500cdd5ed5ed2dfb0",
    "url": "/Covid19-Peru/index.html"
  },
  {
    "revision": "c7c40b5ee21354670cd9",
    "url": "/Covid19-Peru/static/css/10.08a4c718.chunk.css"
  },
  {
    "revision": "ab6e1699f2354cfbe7ce",
    "url": "/Covid19-Peru/static/css/11.b88355da.chunk.css"
  },
  {
    "revision": "75cd9b6cf6df7a9930fa",
    "url": "/Covid19-Peru/static/css/12.b88355da.chunk.css"
  },
  {
    "revision": "42efee394081effecf6c",
    "url": "/Covid19-Peru/static/css/3.3adc8b4e.chunk.css"
  },
  {
    "revision": "6d149636f956224f7211",
    "url": "/Covid19-Peru/static/css/4.74a952cb.chunk.css"
  },
  {
    "revision": "051fb6cd78f5598debd6",
    "url": "/Covid19-Peru/static/css/5.36193cd3.chunk.css"
  },
  {
    "revision": "ea5bf5f08ae236455d49",
    "url": "/Covid19-Peru/static/css/6.8989c793.chunk.css"
  },
  {
    "revision": "ff2b53f35b8926f27303",
    "url": "/Covid19-Peru/static/css/7.02db7aa9.chunk.css"
  },
  {
    "revision": "d3de1979bcdecc265803",
    "url": "/Covid19-Peru/static/css/9.ac83c7f2.chunk.css"
  },
  {
    "revision": "2b4a067e88a7b3067eb6",
    "url": "/Covid19-Peru/static/css/main.df89a53d.chunk.css"
  },
  {
    "revision": "78b065a856b8a47af008",
    "url": "/Covid19-Peru/static/js/index.0.7782741d.production.chunk.min.js"
  },
  {
    "revision": "fded430938324793c4e4",
    "url": "/Covid19-Peru/static/js/index.02a05a0e.production.min.js"
  },
  {
    "revision": "c7c40b5ee21354670cd9",
    "url": "/Covid19-Peru/static/js/index.10.161e2ca5.production.chunk.min.js"
  },
  {
    "revision": "ab6e1699f2354cfbe7ce",
    "url": "/Covid19-Peru/static/js/index.11.9ea97369.production.chunk.min.js"
  },
  {
    "revision": "75cd9b6cf6df7a9930fa",
    "url": "/Covid19-Peru/static/js/index.12.94bf906c.production.chunk.min.js"
  },
  {
    "revision": "0df02304dd841b6e70ab",
    "url": "/Covid19-Peru/static/js/index.13.7fa56380.production.chunk.min.js"
  },
  {
    "revision": "42efee394081effecf6c",
    "url": "/Covid19-Peru/static/js/index.3.c4dafd1d.production.chunk.min.js"
  },
  {
    "revision": "5035c289b7f4237f99c5f07b46faf6d0",
    "url": "/Covid19-Peru/static/js/index.3.c4dafd1d.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "6d149636f956224f7211",
    "url": "/Covid19-Peru/static/js/index.4.6549f985.production.chunk.min.js"
  },
  {
    "revision": "051fb6cd78f5598debd6",
    "url": "/Covid19-Peru/static/js/index.5.aa20a81a.production.chunk.min.js"
  },
  {
    "revision": "ea5bf5f08ae236455d49",
    "url": "/Covid19-Peru/static/js/index.6.b950504e.production.chunk.min.js"
  },
  {
    "revision": "ff2b53f35b8926f27303",
    "url": "/Covid19-Peru/static/js/index.7.02b15974.production.chunk.min.js"
  },
  {
    "revision": "5edcb99535a2125f12db",
    "url": "/Covid19-Peru/static/js/index.8.02c7afec.production.chunk.min.js"
  },
  {
    "revision": "d3de1979bcdecc265803",
    "url": "/Covid19-Peru/static/js/index.9.432f3821.production.chunk.min.js"
  },
  {
    "revision": "2b4a067e88a7b3067eb6",
    "url": "/Covid19-Peru/static/js/index.main.43f59b82.production.chunk.min.js"
  },
  {
    "revision": "0b144332ef224c55b7a5d1a6c183ec46",
    "url": "/Covid19-Peru/static/media/ElPapiChurro.0b144332.jpg"
  },
  {
    "revision": "115563dc17f768eafed7ef0c6253fa24",
    "url": "/Covid19-Peru/static/media/Un_wapo.115563dc.jpg"
  },
  {
    "revision": "9e609414a58194f824ad8fef740ed12a",
    "url": "/Covid19-Peru/static/media/conversacion.9e609414.svg"
  },
  {
    "revision": "6a2667fe962749da85b25a534c52244a",
    "url": "/Covid19-Peru/static/media/coronavirus192.6a2667fe.png"
  },
  {
    "revision": "d7afa43e8273de4bcdf849423dceb20b",
    "url": "/Covid19-Peru/static/media/covid_19.d7afa43e.svg"
  },
  {
    "revision": "c64430b2948cadf3e67a1a01b8fb1f78",
    "url": "/Covid19-Peru/static/media/css-3.c64430b2.svg"
  },
  {
    "revision": "700dba7024b41484270b6d1dc85d2f7d",
    "url": "/Covid19-Peru/static/media/facebook.700dba70.svg"
  },
  {
    "revision": "231a5fc81a7a78d0308dccd5cabecc6e",
    "url": "/Covid19-Peru/static/media/herramienta.231a5fc8.svg"
  },
  {
    "revision": "73cd6e837bf0a9fbf55d6baa5f2b7ab2",
    "url": "/Covid19-Peru/static/media/icomoon.73cd6e83.woff"
  },
  {
    "revision": "79b0c7dcdf84a0b1c602b266120f5635",
    "url": "/Covid19-Peru/static/media/icomoon.79b0c7dc.eot"
  },
  {
    "revision": "ab73b031a1039598636ba8f7e5ea37c2",
    "url": "/Covid19-Peru/static/media/icomoon.ab73b031.svg"
  },
  {
    "revision": "e462b23a3ebd1e11443e1077f68f26d7",
    "url": "/Covid19-Peru/static/media/icomoon.e462b23a.ttf"
  },
  {
    "revision": "037f2a0625c78965d7d3a36547baca80",
    "url": "/Covid19-Peru/static/media/javascript.037f2a06.svg"
  },
  {
    "revision": "ea281c140abab3c8337e82dc1729d93e",
    "url": "/Covid19-Peru/static/media/jose-cueva-celis.ea281c14.jpg"
  },
  {
    "revision": "83946a33ce2612175fca81972fffd4b0",
    "url": "/Covid19-Peru/static/media/lavar las manos.83946a33.jpg"
  },
  {
    "revision": "663c0b554e32200cc45f748677c3788e",
    "url": "/Covid19-Peru/static/media/llamar.663c0b55.jpg"
  },
  {
    "revision": "a39b3f198283271a11fbbc026de65169",
    "url": "/Covid19-Peru/static/media/pañuelo.a39b3f19.jpg"
  },
  {
    "revision": "5257bedaec6beae772b699f1e3fa6e74",
    "url": "/Covid19-Peru/static/media/reaccionar.5257beda.svg"
  },
  {
    "revision": "7a4d9f0fe157437d3258bbc3b785066d",
    "url": "/Covid19-Peru/static/media/twitter.7a4d9f0f.svg"
  },
  {
    "revision": "a51ab7ed010a415170cd93a2a29d96dd",
    "url": "/Covid19-Peru/static/media/youtube.a51ab7ed.svg"
  }
]);